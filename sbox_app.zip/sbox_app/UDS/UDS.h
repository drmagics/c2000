#ifndef _UDS_H
#define _UDS_H
#include "typedefs.h"
#include "ISOTP.h"
//#include "MPC5634M_MLQC80.h"
//#include "API.H"
#include "global.h"

#define VIN_LEN      17
#define MIN_LEN      11
#define CQ_LEN       15
#define MKDATE_LEN   9
#define ErrSave_LEN  50
#define BLE_UDS_CMD_CONNECT 			(1 << 0)
#define BLE_UDS_CMD_WRITE_VIN 		    (1 << 1)
#define BLE_UDS_CMD_READ_VIN 	        (1 << 2)
#define BLE_UDS_CMD_SEND_SL_DTC		    (1 << 3)
#define BLE_UDS_CMD_DEL_SL_DTC			(1 << 4)
#define BLE_UDS_CMD_READ_DTC			(1 << 5)
#define BLE_UDS_CMD_DEL_DTC			    (1 << 6)
#define BLE_UDS_CMD_UP_VCU			    (1 << 7)

//extern void UDS_Fuction(uint8_t error_code);
extern void Time_Watch(void);
extern void UDS_SREVE(void);
extern uint32_t UDS_RESPOND_ID;

extern uint16_t system_error_num;
extern uint8_t Dtc_Err_Save_Flag;
extern uint8_t DTC_Error_Actual_Code_Data[ErrSave_LEN];
extern uint8_t error_code_data_ReadEE[ErrSave_LEN];
extern uint8_t error_code_exchange;//�����µĹ��ϴ洢Ϊ��һ���ı��
extern uint8_t Time_refresh;
extern uint8_t Dtc_Err_Clear_Flag;
extern uint8_t EEPROM_DTC_Cnt;

extern uint8_t VIN_Receive_Comp_Flag ;
extern uint8_t uds_task_flag;
extern uint8_t uds_connect_status;
extern uint8_t uds_connect(void);
extern uint8_t uds_write_vin(void);
extern uint8_t uds_send_sl_dtc(void);
extern uint8_t uds_clear_SL_DTC(void);
extern uint8_t uds_read_DTC(void);
extern uint8_t uds_clear_DTC(void);
extern uint8_t uds_up_vcu(void);
extern  void  CanUpg_RecvData(uint32_t ID,uint32_t*Data,uint8_t Length);
// uds����״̬
#define UDS_STATUS_DISCONNECT	0
#define UDS_STATUS_CONNECTED	1






extern uint8_t	buff_read_flag;
extern uint8_t	modify_session_flag;                                    /* �޸ĻỰ��־ */
extern uint8_t	secure_session_flag;                                    /* ��ȫ�Ự��־ */
extern uint8_t	verify_session_flag;                                    /* ��֤�Ự��־ */
extern uint8_t	Write_Vin_flag;                                         /* д��VIN��ı�־ */
extern uint8_t	write_success_flag;                                     /* д��VIN��ɹ��ı�־ */
extern uint8_t	Read_Vin_flag;                                          /* ��ȡVIN��ı�־ */
extern uint8_t	read_success_flag;
extern uint8_t	Send_Sl_DTC_flag;
extern uint8_t	send_success_flag;
extern uint8_t  Clear_Sl_DTC_flag;
extern uint8_t  clear_success_flag; 
extern uint8_t  Read_DTC_flag;
extern uint8_t  Clear_DTC_flag;
extern uint8_t	read_DTC_success_flag;
extern uint8_t  Read_DTC_Cnt;
extern uint8_t  SL_DTC;
extern uint8_t  clear_DTC_success_flag;
extern uint8_t  UDS_DTC_CODE[8];
extern uint8_t	buff[4095];
//extern uint8_t	callback;
extern uint8_t  modify_funsession_flag;
extern uint8_t  comm_funsession_flag ;
extern uint8_t	modify_session_flag1;
extern uint8_t  request_download_flag;
extern uint8_t  start_secure_flag ;
extern uint8_t  UpgProgAddr[4] ;
extern uint8_t  UpgProgSize[4] ;
extern uint8_t  UpgCrcCode[4] ;
extern uint8_t  Download_Data_Sendout[320] ;
extern uint8_t  sendsize ;
extern uint8_t  uds_upgrade_state ;
extern uint8_t  uds_status ;

#define UDS_UPG_ERASE_FLASH     0x01
#define UDS_UPG_DOWN_START      0x02
#define UDS_UPG_DOWN_END        0x03
#define UDS_UPG_VCU_RESET       0x04
#define UDS_UPG_VCU_END1        0x05
#define UDS_UPG_VCU_END2        0x06
#define UDS_UPG_VCU_END3        0x07

#define uds_upgrade_start       0x01
#define uds_upgrade_send        0x02
#define uds_upgrade_end         0x03


typedef struct {
	
	void (*callBack)(uint8_t *);
		
} uds_task_t;


extern uds_task_t uds_task;


typedef struct 
{
    uint8_t  Year;
    uint8_t  Month;
	uint8_t  Day;
	uint8_t  Hour;
	uint8_t  Min;
	uint8_t  Second;

} UDS_Time;//UDS�����ʱ���

#pragma pack(push)//�ṹ��8�ֽڶ���
#pragma pack(8)
typedef struct 
{
      uint8_t  VIN17[VIN_LEN];      //��ȡ����17λvin
      uint8_t  MIN11[MIN_LEN];      //��ȡ����11λMIN������
	  uint8_t  CQ15[CQ_LEN];        //�ϸ�֤
	  uint8_t  MKDATE9[MKDATE_LEN]; //��������
	//float    Expect_Remain_Mile_Save;//�������
	  uint8_t  DTC_code[ErrSave_LEN];//��ʷ���ϴ���
	  uint8_t  RemainTimes;      //ʣ�����
      uint8_t  Flash_Valve;      //Flash��Ч �ϴε�����������Ч
} FlashData,*P_FlashData;
#pragma pack(pop)


extern FlashData Flash;  
extern UDS_Time Time; 
extern void WriteFlashData(uint32_t WriteAddress, uint8_t *buf, uint32_t len) ;
extern  void UDS_upgrade_ack(uint8_t cmd, uint8_t ack);
#endif
