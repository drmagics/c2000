#include "typedefs.h"

//------M95512 �ڴ��ַ����------------
#define EEPROM_Page0_Addr   0x00000000
#define EEPROM_Page1_Addr   0x00000080
#define EEPROM_Page2_Addr   0x00000100
#define EEPROM_Page3_Addr   0x00000180
#define EEPROM_Page4_Addr   0x00000200
//------------------------------------


#ifndef LOCKED
#define LOCKED 0x55
#define OPEN   0xaa
#endif

/*CANID�趨*/
/*�������ID*/
#define MCU1_VCU_ID   0x18FF0FEF//0x0C61D0D1
#define MCU2_VCU_ID   0x18FF10EF//0x0C62D0D1
#define MCU3_VCU_ID   0x18FF1EEF//0x0C63D0D1
/*VCU���͸����ID*/   
#define VCU_MCU_ID    0x0C64D1D0 

/*BMS����ID*/
#define BMS1_VCU_ID 0x18FF2CF3//0x1806F489
#define BMS2_VCU_ID 0x18FF2DF3//0x1807F489
#define BMS3_VCU_ID 0x18FF2EF3//0x181BF489   
#define BMS4_VCU_ID 0x18FF2FF3//0x182BD589
#define BMS5_VCU_ID 0x18FF30F3//0x186DD589     

/*Զ�̼�ط���ID*/
#define ISO_B_ID    0x0C3CD0F4

/*�Ǳ�����ID*/
#define METER1_B_ID 0x0C35D5F4   

/*������Դ���ͱ���*/
#define DCDC_B_ID   0x18FFB5D8//0x18F7F4D4
#define DCDC_B1_ID   0x18FFB6D8//0x18FDD0D6

/*Զ���ն˷��ͱ���*/
#define REMOTE1_B_ID   0x18FFD0D6
#define REMOTE2_B_ID   0x18FED0D6

//Զ����������
#define Remote_Lock_ID   0x1801D0D8
#define LED_ALL  (UWord32)0x03fff
#define VEHICLE_INFORMATION  0x31       //����Ϊ�Զ������綯�ͳ������Ϊ����ӵ��
#define VEHICLE_STOP_MODE    0          //ͣ��ģʽ
#define VEHICLE_FRONT_MODE   1          //ǰ��ģʽ
#define VEHICLE_BACK_MODE    4          //����ģʽ
#define VEHICLE_line_MODE   3          //����ģʽ
#define VEHICLE_ERROR_MODE   2          //����ģʽ
#define VEHICLE_CHECK_MODE   5           //�Լ�ģʽ
#define VEHICLE_CHARGE_MODE 8          //�������ģʽ
#define VEHICLE_CHARGE_MODE_DC 7          //ֱ�����ģʽ
#define VEHICLE_APS_MODE 9          //��Դģʽ
#define DIRECTION_FRONT      1
#define DIRECTION_BACK       4
#define DIRECTION_NEUTRAL    0
#define BATTERY_SERIAL_NUM  120         //��ش�������
#define MOTOR_MAX_BRAKE_VOLTAGE 480
#define MOTOR_MIN_DRIVE_VOLTAGE 260
#define MOTOR_MAX_BRAKE_CURRENT 300
#define MOTOR_MAX_DRIVE_CURRENT 400
//ԭmain.c�ж���
extern vuint8_t  nAppCmdCounter;
extern uint32_t OutFreq1,OutDuty1;
extern uint32_t OutFreq2,OutDuty2;
extern uint32_t OutFreq3,OutDuty3;
extern uint32_t OutFreq4,OutDuty4;
extern uint32_t InFreq[4],InDuty[4];
extern uint32_t CanID;
extern uint32_t CanDataa1[2];
extern uint32_t CanDataa2[2];
extern uint32_t CanDataa3[2];
extern uint32_t CanDataa4[2];
extern uint32_t CanData3[2];
extern uint32_t CanData31[2];
extern uint32_t CanData32[2];
extern uint32_t CanData33[2];
extern uint32_t CanDataC[2];
extern uint32_t CanDataC1[2];
extern uint32_t CanDataC2[2];
extern uint32_t CanDataC3[2];
extern int16_t AdcCalcResult[18];
extern uint8_t EepromBuff[8];
extern uint8_t SciData;
extern float drive_accelrate_pedal;
extern float drive_accelrate_pedal_volt;
extern float drive_brake_pedal_volt;
extern float motor_target_torque;
extern vint32_t motor_max_torque_can;
extern vint32_t motor_input_voltage_limit;
extern vint16_t motor_input_current_limit;
extern uint8_t main_controler_life;
extern float motor_actual_torque;
extern vint16_t motor_speed;
extern float motor_controller_input_voltage;
extern uint8_t drive_counter1;
extern float drive_accelrate_pedal_volt_temp[256];
extern float drive_accelrate_pedal_volt_temp2[256];
extern float drive_accelrate_pedal_volt_suv;
extern float drive_brake_pedal_volt_suv;
extern int16_t drive_brake_pedal_volt_temp[256];
extern uint16_t motor_controller_error_code;
extern uint16_t prev_motor_controller_error_code;
extern int8_t motor_temprature;
extern int8_t motor_controller_temprature;
extern vint16_t motor_controller_input_current;
extern uint8_t motor_controller_life;
extern vint16_t motor_speed_temp;
//ԭmain_control.c
extern uint8_t vehicle_drive_mode;
extern uint8_t drive_direction;
extern vuint8_t error_mode_count;
extern uint8_t hand_brake;
extern float drive_brake_pedal;
extern uint8_t switch_second;
extern uint8_t motor_target_mode;
extern uint8_t error_process_type;
extern uint8_t error_stop_enable;
extern float motor_input_power_limit;
extern float temp1;
extern float temp2;
extern float temp3;
extern float temp4;
extern float temp5;
extern float temp6;
extern float tempa;
extern float tempb;
extern float tempc;
extern float tempd;
extern float tempe;
extern float tempf;
extern float tempg;
extern uint8_t gear_neutral;
extern uint8_t gear_front;
extern uint8_t gear_back;
extern uint8_t error_mot_limitpower;
extern uint8_t error_apu_limitpower;
extern uint32_t error_show_number[64];
extern uint32_t error_number_array[256];        //���ϴ�������
extern float motor_limit_speed;
extern float battery_max_discharge_current;                //�������������
extern float battery_max_charge_current;         //����������ƶ�����
extern float bat_max_discharge_current_allow;
extern float uc_single_module_volt_min;            //��ص�����͵�ѹ
extern float uc_single_module_volt_max;            //��ص�����ߵ�ѹ
extern float  bat_max_charge_current_allow;
extern float drive_target_torque;                //̤���������ǣ��Ŀ��ת�
extern float drive_target_brake_torque;          //̤����������ƶ�Ŀ��ת�� 
extern float watch_temp;
extern float target_traction_torque;
extern uint32_t TleOutValue;		//ͨ�����ֵ(�Զ����),BIT0=CH0,1=����ߵ�ƽ(�����Ч),0=����͵�ƽ(�����Ч)
extern uint8_t TleDiaInfo[5];		//ͨ�������Ϣ������(�Զ���ȡ),ÿ2λ��ʾһ��ͨ��,
extern uint8_t electric_brake_enable;
extern uint8_t ready_lamp;
extern uint8_t error_lamp;
extern uint8_t motor_fan;
extern uint32_t DataDialogCt1[2];
extern uint32_t DataDialogCt2[2];
extern uint32_t DataDialogCt3[2];
extern uint32_t DataDialogCt4[2];
extern uint32_t DialogDataa[2];
extern uint8_t DialogSendFlg;
extern uint32_t DataAt[2];
extern uint32_t DataAt1[2];
extern uint32_t Data3t[2];
extern uint32_t DataCt[2];
extern uint32_t DataCt1[2];
extern uint32_t DataCt2[2];
extern uint32_t DataCt3[2];
extern uint32_t DataCt4[2];
extern uint32_t DataCt5[2];
extern uint32_t DataCt6[2];
extern uint32_t DataCt7[2];
extern uint32_t DataCt8[2];
extern uint32_t DataCt9[2];
extern uint32_t DataCt10[2];
extern uint32_t DataCt11[2];
extern uint32_t DataCt12[2];
extern uint32_t DataCt13[2];
extern uint32_t DataCt14[2];
extern uint32_t DataCt15[2];
extern uint32_t DataCt16[2];
extern uint32_t DataCt17[2];
extern uint32_t DataCt19[2];
extern uint32_t	DataCt24[2];
extern uint32_t	DataCt25[2];
extern uint32_t	DataCt26[2];
extern uint32_t	DataCt27[2];

extern uint8_t error_temporary_array[10][8];
extern uint8_t system_error_code;
extern float uc_battery_voltage;
extern float uc_battery_current;
extern float battery_soc;
extern uint8_t DC_Control;
extern uint8_t Pump_Control;
extern uint8_t Airpump_Control;
extern uint8_t Air_condition_control;
extern uint8_t motor_pump;
extern uint8_t HV_relay_counter1;
extern uint8_t HV_Relay_Status;
extern uint8_t battery_error;
extern uint8_t BMS_life;
extern float BMS_Version;
extern uint32_t CanDataC4[2];
extern uint32_t CanDataC5[2];
extern uint32_t CanDataC6[2];
extern uint32_t CanDataC7[2];
extern uint32_t CanDataC8[2];
extern uint32_t CanDataC9[2];
extern uint16_t vehicle_speed;
extern uint8_t main_controler_life_bms;
extern uint16_t DacValue1;
extern uint16_t DacValue2;
extern uint16_t DacValue3;
extern uint16_t DacValue4;
extern uint8_t Precharge_K5;
extern uint8_t Maincon_Relay ;
extern uint16_t Precharge_Flag ;
extern uint8_t Precharge_Init;
extern struct DisData_tag DisData;

//-------------------------------------------------------
extern uint16_t   HighLevelAdVaule;      // �ߵ�ƽ�ж���ֵ
extern uint16_t   LowLevelAdVaule;       // �͵�ƽ�ж���ֵ

extern uint16_t   NoConnectAdVauleMax;   // ����̬�ж���ֵ
extern uint16_t   NoConnectAdVauleMin;   // ����̬�ж���ֵ

extern uint16_t  eQAdcVaule[50];     // Test Liu
extern uint8_t   eQAdcChannel;       // Test Liu
extern uint8_t   DigitalInputStatus[20];    // Test Liu  16·����������״̬
extern uint8_t   DigitalInputStaMonit[20];  // Test Liu  16·����������״̬���
extern uint8_t   DigitalOutChannel[20];     // Test Liu  18·���������״̬ TLE6244
extern uint8_t   DigitalOutputStaMonit[20]; // Test Liu  13·���������״̬���
extern uint16_t  MonitMCU_Adc[24];  // Test Liu  ������Ƭ��Adc
extern uint16_t  MonitMCU_Plus[8];  // Test Liu  ������Ƭ��PTM
extern uint16_t  MonitMCU_Rtc;	    // Test Liu  ������Ƭ��RTC
#define  DIN_PowerOn  SIU.GPDI[134].B.PDI    // ����Կ�׵�Դ�����ź�
extern float DCDC_OutputVol;
extern float DCDC_InputVol;
extern uint8_t DCDC_Err_Status ;
extern uint8_t ABS_Active_Flg;
extern uint8_t DCDC_Life ;
extern float DCAC_InputVol ;
extern float DCAC_OutputCur ;
extern float DCAC_InputCur ;
extern uint8_t DCAC_Err_Status ;
extern uint8_t DCAC_Life ;
extern float DCAC_AirOutputVol ;
extern float DCAC_AirOutputCur ;
extern float DCAC_AirInputCur ;
extern uint8_t DCAC_Err_AirStatus ;
extern uint8_t DCAC_AirLife ;
extern uint8_t DC_Charge;
extern uint8_t AC_Charge;
extern uint32_t CanDataC10[2];
extern uint32_t CanDataC11[2];
extern uint32_t CanDataC12[2];
extern uint32_t CanDataC13[2];
extern uint8_t Key_Start;
extern uint16_t Befor_Air_Press;
extern uint16_t Back_Air_Press;
extern uint8_t ECO_Mode;
extern float drive_accelrate_pedal_volt_suv2;
extern float drive_accelrate_pedal_volt2;
extern uint8_t Check_OK_Flg;
extern uint8_t Check_NG_Flg;
extern uint32_t Receive_VIN[6];
extern uint8_t Key_Start_flag;
extern uint8_t VCU_BMS_PwrCmd;
extern uint8_t EHPS_Mode;
extern uint8_t BMS_ChgCabSts;
extern uint8_t charge_status;
extern uint8_t INs_Life;
extern float drive_accelrate_pedal2;
extern uint8_t BMS_Err_Tyte;
extern uint8_t EHPS_Check_Flg;
extern uint16_t Steering_Wheel_Angle ;
extern uint8_t Steering_Wheel_Cnt ;
extern uint8_t Steering_Wheel_Cnt_Type ;
extern uint8_t Steering_Wheel_Range ;
extern uint8_t Steering_Active_Mode;
extern uint8_t Steering_SAS_Calib ;
extern uint8_t Steering_Mess_Cnt;
extern uint8_t Steering_Mess_CheckSum ;
extern uint8_t EHPS_Frist_Send_MesFlg ;
extern uint8_t Second_Send_MesFlg;
extern uint8_t EHPS_CalCompleted_Flg;
extern uint8_t Vehicle_Creep_Flg;
extern uint8_t Brake_Input_DIN_B;
extern float Brake_Input_AIN_F;
extern uint8_t Vacuum_Pump;
extern uint8_t motor_fan_high;	
extern uint8_t motor_fan_low;
extern float Vacuum_Air_volt;
extern uint8_t Air_Switch_One;
extern uint16_t Air_Speed_Control;
extern uint8_t Air_life;
extern uint16_t Air_Speed;	
extern uint8_t Air_Requst_Off;
extern uint8_t Defrost_switch_con;
extern uint8_t Warm_Wind_Con;
extern uint8_t Eco_enery_Mode;
extern uint8_t Stop_Run_con;
extern uint8_t Air_switch_con;
extern uint8_t Ele_Defrost_Control;
extern float Vacuum_Air_Precent;
extern uint8_t Leakage_Flg;
extern uint8_t	BMS_ChgrRlySts;//�����Ӵ���״̬
extern uint16_t HV_relay_counter3;
extern uint8_t Maincon_Relay2;
extern uint8_t Precharge_error;
extern uint8_t PreRelayCnt;
extern uint8_t main_500ms_life;
extern uint8_t MCU_Relay_Neg_DO;
extern uint8_t BMS_Mode;
extern uint8_t	BMS_ChgCabSts;
extern uint8_t BMS_Error_Type;
extern uint8_t Motor_Work_Mode;
extern uint8_t MCU_Enable;
extern uint8_t Vehcle_IsoLife;
extern uint8_t prev_Vehcle_IsoLife;
extern uint8_t Vehcle_IsoFlt;
extern vint16_t Demand_Torque;
extern int16_t Demand_Speed;
extern uint8_t Motor_Drive_Mode;
extern uint8_t	BMS_PrechgSts;//Ԥ���״̬
extern uint8_t	BMS_PrechgRlySts;//Ԥ���Ӵ���״̬
extern uint8_t	BMS_PosRlySts;//�����Ӵ���״̬
extern uint8_t BMS_CellHVoltNum;
extern float BMS_CellHVolt;
extern uint8_t BMS_CellLVoltNum;//������͵�ѹ���
extern float BMS_CellLVolt;//������͵�ѹ
extern uint8_t	BMS_life2;
extern uint8_t	BMS_SelfChkSts;//BMS�Լ�״̬
extern uint8_t	BMS_SOH;//���SOH
extern int8_t	BMS_HTemp;//�������¶�
extern int8_t	BMS_LTemp;//�������¶�
extern uint8_t	BMS_ChgSts;//���״̬
extern uint8_t	BMS_NegRlySts;//�ܸ��Ӵ���״̬
extern uint8_t	BMS_HeatSysSts;//��ؼ���ϵͳ����״̬
extern uint8_t	BMS_CoolSysSts;//�����ȴϵͳ����״̬
extern uint8_t	BMS_MoisSts;//���ʪ��״̬
extern int8_t	BMS_SustChgPwrAllwd;//�����ó�����繦��
extern int8_t	BMS_InstChgPwrAllwd;//�����ö�ʱ��繦��
extern uint8_t	BMS_SustDischgPwrAllwd;//�����ó����ŵ繦��
extern uint8_t	BMS_InstDischgPwrAllwd;//�����ö�ʱ�ŵ繦��
extern float	BMS_PosIsoR;//������Ե��ֵ
extern float	BMS_NegIsoR;//������Ե��ֵ
extern uint8_t	BMS_IsoFlt ;//BMS��Ե����
extern uint8_t	BMS_PrechgFlt ;//Ԥ������
extern uint8_t	BMS_PosRlyFlt ;//�����Ӵ�������
extern uint8_t	BMS_NegRlyFlt ;//�ܸ��Ӵ�������
extern uint8_t	BMS_PrechgRlyFlt ;//Ԥ��Ӵ�������
extern uint8_t	BMS_ChgrRlyFlt	;//�����Ӵ�������
extern uint8_t	BMS_LTempFlt ;//�¶ȹ��͹���
extern uint8_t	BMS_HTempFlt ;//�¶ȹ��߹���
extern uint8_t	BMS_DeltaTempFlt ;//�¶Ȳ������
extern uint8_t	BMS_HMoisFlt ;//ʪ�ȹ������
extern uint8_t	BMS_OvrChgFl ;//����������
extern uint8_t	BMS_OvrDischgFlt ;//�ŵ��������
extern uint8_t	BMS_CellHVoltFl ;//�����ѹ����
extern uint8_t	BMS_CellLVoltFlt ;//����Ƿѹ����
extern uint8_t	BMS_CellDeltaVoltFlt ;//�����ѹ�������
extern uint8_t	BMS_PackHVoltFlt ;//������ѹ����
extern uint8_t	BMS_PackLVoltFlt ;//�����Ƿѹ����
extern uint8_t	BMS_LSOCFlt ;//SOC���͹���
extern uint8_t	BMS_HSOCFlt ;//SOC���߹���
extern float  DC_DC_OutputCur;
extern uint8_t DCDC_WorkStatus;	
extern uint8_t	DCAC_AirTemp;
extern uint8_t DCDC_Error;
extern uint8_t DCAC_Error;
extern uint8_t DCACAir_Error;
extern float motor_controller_Output_voltage;
extern uint8_t Air_Conditioning_FB;
extern uint8_t Vacuum_Pump_FB;
extern uint8_t Air_ConditonRly_Flg;
extern uint16_t Vehcle_Iso_Resist;
extern uint16_t VCU_Version; 
extern uint16_t VCU_Year;
extern uint16_t VCU_Month_Day;
extern uint8_t  Motor_Numer;
extern uint8_t  Vehicle_Type;
extern uint8_t Fail_Grade ;
extern uint8_t Vehicle_Hatch_Gate;
extern uint8_t DFront_Door_Status ;
extern uint8_t Back_Door_Status ;
extern uint8_t Mid_Door_Status ;
extern uint16_t Motor_Speed_Array[23];
extern uint16_t Motor_Max_Torque[23];
extern uint16_t Motor_Back_Max_Torque[23];
extern int16_t Creep_Motor_Speed_Array[21];
extern uint16_t Creep_Motor_Max_Torque[21];
extern int16_t drive_motor_speed;
extern uint16_t U16_Forbid_Slipe_Up_Rate;
extern uint16_t U16_Creep_Up_Rate;
extern int16_t S16_Creep_Down_Rate; 
extern uint16_t Vehicle_Speed_Array[17];
extern float Hand_Target_Motor_Gain[17];
extern float Target_Motor_Gain[17];
extern int16_t S16_Frist_Down_Rate;
extern uint16_t motor_max_torque_limit;
extern int16_t Batter_Current_Array[27];
extern float Drive_Target_torque_Gain[27];
extern uint16_t Brake_Motor_Speed_Array[23];
extern uint16_t Brake_Motor_Max_Torque[23];
extern uint16_t Target_Torque_Array[14];
extern uint16_t Torque_Uprate_Array[14];
extern int16_t Torque_Downrate_Array[14];
extern uint16_t Torque_Uprate_Array1[14];
extern int16_t Torque_Downrate_Array1[14];
extern uint16_t Motor_Allow_Max_Current;
extern uint16_t Motor_Torque_UpRate;   
extern int16_t Motor_Torque_DownRate;
extern uint16_t Slip_brake_torque_MIN;
//������ƶ�����
extern uint16_t Slip_brake_torque_MAX;
//�����ƶ�����
extern uint8_t Slip_Allow_Flg;
//�����ƶ���С���ճ���
extern uint8_t slip_brake_min_vehicle;
//�����ƶ���ʼ���ճ��٣������ٴ���slip_brake_start_vehicle�����ƶ����գ�����С��slip_brake_min_vehicle���޻��գ��м�Ϊ������
extern uint8_t slip_brake_start_vehicle;
extern uint8_t Slip_Brake_Flg;
extern uint8_t MCU_Slip_Flg;
extern uint8_t MCU_Creep_Flg;
extern uint8_t MCU_Allow_Flg;
extern uint8_t MCU_Err_Flg;
extern uint8_t Din_Change_Awaken;
extern uint8_t Din_Mid_Press_Con;
extern uint8_t Din_Cruise_Dis_Con;
extern uint8_t Din_Cruise_Open_Con;
extern float Evaporator_Temperature_Volt;
extern float Brake_Pedal_Array[11];
extern float Brake_Target_torque_Gain[11];
extern uint8_t MCU_Err_three;
extern uint8_t MCU_Err_two;
extern uint8_t MCU_Err_One;
extern uint8_t BMS_Err_three ;
extern uint8_t BMS_Err_two ; 
extern uint8_t BMS_Err_One ;
extern uint8_t BMS_Request_OFF;
extern uint8_t BMS_HotRlySts;       
extern uint8_t BMS_SlowChgRlySts;     
extern uint8_t BMS_QuikChgRlySts;      
extern uint8_t BMS_Get_Volt_Process;  
extern vint8_t BMS_TempH_Limit;    
extern vint8_t BMS_TempL_Limit;    
extern uint8_t BMS_Batter_Decay; 
extern uint8_t BMS_SOCL_Limit;  
extern float BMS_Change_Precent;
extern uint8_t Enter_Front_Back_Flg;
extern uint8_t GEAR_Status;
extern uint8_t GEAR_Status1;
extern uint8_t Gear_Delay_Cnt;
extern uint32_t Vehicle_Mileage;
extern uint8_t Other_Err_Cnt;
extern uint8_t Other1_Err_Cnt;
extern float Batter_Volt;
extern uint8_t Remote_Self_Check;
extern uint8_t Remote_Lock;
extern uint8_t Remote_Lock_Air;
extern uint8_t Remote_Lock_Warm;
extern float	Remote_Limit_Power_Gain;
extern uint16_t MAPX_Vehicle_Speed[11];
extern uint16_t MAPY_Slip_Current[11];
extern int16_t Evaporator_Temperature;
extern uint16_t Evaporator_Temperature_Resist;
extern uint16_t MAPX_Temp_Resist[13];
extern float TransGearAxleRatio_F;
extern float Remainde_Electric; //ʣ�����kw
extern float Instant_Comsumption; //˲ʱ���kw/h
extern float Average_Comsumption;//ƽ����� kw/h
extern float Remainde_Time;       //ʣ��ʱ�� h
extern float BMS_Stand_Electric;
extern float Remainde_Mileage; 
extern float Remainde_Max_Mileage; 
extern uint32_t Vehicle_Mileage_D;
extern float TransWheelRadius_F;
extern uint8_t Frist_Read_Data; 
extern int16_t MAPY_Temp_Array[13];
extern vuint8_t VIN_num;
extern uint8_t charge_awaken;
extern uint8_t HV_quick_off;
extern uint8_t Brake_Power;
extern uint8_t Err_Out_status ;  // �������״̬
extern uint8_t Gear_panel_Power ;
extern uint8_t Acces_PwrCmd;
extern uint8_t Air_conditon_Power;
extern uint8_t Airpump_Pres_Relief;
extern uint8_t Back_status;
extern uint8_t Airpump_fan;
extern uint8_t ready;
extern uint8_t Power_reduce;
extern vuint32_t system_error_type;
extern uint8_t soc_low_type;
extern uint8_t	VCU_NegRlySts;
extern uint8_t BMS_Fault_Array[40];
extern uint8_t ERROR_Cycle1_ErrorSPN[40];
extern uint8_t battery_error_code;
extern uint8_t BMS_Fault_Array_Show[40];
extern uint8_t ERROR_Cycle1_ErrorCnt[40];
extern uint16_t motor_controller_error;
extern uint8_t MCU_Fault_Array[40];
extern uint8_t MCU_Fault_Array_Show[40];
extern uint8_t ERROR_Cycle2_ErrorSPN[40];
extern uint8_t ERROR_Cycle2_ErrorCnt[40];
extern uint8_t MCU_Err_Type;
extern uint8_t prev_DCDC_error_code;
extern uint8_t prev_DCAC_error_code;
extern uint8_t prev_DCACAir_error_code;
extern vuint8_t DCDC_error_counter;
extern vuint8_t DCAC_error_counter ;
extern vuint8_t DCACAir_error_counter ;
extern uint16_t On_Off_Err_count;
extern uint8_t Pump_WorkStatus ;       		
extern uint8_t DCAC_AirPumpWorkStatus; 
extern uint8_t GEAR_Invalid_flg;
extern uint8_t Remote_Lock_flg ;    // Զ��������־   1:������
extern uint8_t Remote_Lock_life; 
extern uint8_t Pre_Remote_Lock_life;
extern uint16_t Gear_panel_count;

extern uint8_t	BMS_HVConSts ;                                      //��ѹ�Ӵ���״̬
//��������
extern uint8_t Blower_Con;
extern uint16_t MCU_DrvMtrDTC ;  // ����������ϴ���
extern uint8_t MCU_Fault_num;//��ع�����
extern uint8_t motor_temp;//������к�
extern uint8_t IGBT_EN ;    // IGBTʹ�ܷ���
extern uint16_t motor_current;  // ������������
extern uint8_t Vehicle_Slope_Flg;//פ�±�־λ
extern uint8_t MCU_Change_Flg;//�����ŵ��־λ
extern uint8_t PTC_HAVC_error;
extern uint16_t vcu_error;
extern uint16_t battery_DTC_error;
extern uint16_t DCDC_DTC_error ;
extern uint16_t EPS_EPSDTC ;
extern uint16_t ThreeInOne_DTC;
extern uint8_t DCDC_Error_Type;
extern uint8_t EPS_Error_Type;
extern uint8_t ThreeInOne_Type;
extern uint8_t BMS_err_Cnt;
extern uint8_t ThreeInOne_RlySts;
extern uint8_t Air_conditon_RlySts;
extern uint8_t Air_conditon_PrechgRlySts;
extern uint8_t EPS_RlySts;
extern uint8_t PTC_RlySts;
extern uint8_t DCDC_RlySts;
extern uint8_t VIN_request;
extern uint8_t VIN_request1;
extern uint8_t LinshiBMSshangdian;
extern uint8_t DCDC_RlySts_Con;
extern uint8_t EPS_RlySts_Con;
extern uint8_t DCDC_RlySts_Cut;
extern uint8_t ThreeInOne_WakeUp;
extern uint8_t PANAL_Allow_Flg;
extern uint8_t Motor_Change_Cnt;
extern uint8_t EPS_RlySts_Cut;
extern uint8_t Pump_Control_Allow;
extern uint8_t Pump_Delay_Cnt;
extern uint8_t Air_condition_RlySts_Cut;
extern uint8_t HAVC_Control;
extern uint8_t front_flg_cut;
extern uint8_t Vehicle_Run_Flg;
extern uint8_t Air_conditon_precharge_cut;//�յ�Ԥ�����
extern uint8_t Air_conditon_maincon_cut;//�յ����Ӵ�������
extern uint8_t Air_conditon_precharge ;  //�յ�Ԥ��ʹ��
extern uint8_t The_Snow_Mode;//ѩ��ģʽ
extern uint8_t PTC_Error_Flg;//PTC�����ź�
extern uint8_t Pump_Fault_Test;//��ձù��ϼ���ź�
extern uint8_t FiveInOne_WakeUp;//���һ�ӳټ̵�������
extern uint8_t front_flg;                        //���Ž�ֹ��־-��ǰ��λ��ʵ�ʲ�����λ��һ��ʱ����ֹ����
extern uint8_t Protect_Slip_Flg ;
extern uint16_t MCU_Slip_Flg_Cnt;
extern uint8_t simulate_Flag;
extern uint8_t Expect_Remain_Mile_Save_Flag;//�ڴ�ʣ����̴洢����
extern uint8_t tans_flg;
extern uint8_t tans_flg1;
extern uint8_t AMT_Minitor_Flg_enble;
extern uint16_t CB_motor_torque;
extern vint16_t CB_motor_speed;
extern float CB_Vehicle_Gain;
