#ifndef __POWER_H__
#define __POWER_H__

#include "common.h"
#include "time_task.h"

void PWR_Init(void);

s32 PWR_Monitor(TimeTask_t *pTimeTask);

void PWR_BatterOff(void);

#endif

