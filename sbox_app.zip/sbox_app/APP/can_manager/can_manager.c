#include "can_manager.h"


/**************************************************
 * can ���ջ��廷
 **************************************************/
#define CAN_RING_SIZE   		512 // can��������С
TYPE_Can can_ring_buf[CAN_RING_SIZE];
int     can_i_get = 0;
int     can_i_put = 0;

int CAN_INC(int val)
{
    return ((val + 1) == CAN_RING_SIZE) ? 0 : (val + 1);
}

void CAN_PutRingItem(TYPE_Can *canMsg)
{		
    if (can_i_get == CAN_INC(can_i_put))
    {
        // FULL
        LOGEln("can msg full");
        return;
    }
			
    memcpy(&can_ring_buf[can_i_put], canMsg, sizeof(TYPE_Can));	
    can_i_put = CAN_INC(can_i_put);
}

u8 CAN_GetRingItem(TYPE_Can *canMsg)
{
    if (can_i_get == can_i_put)
    {
        // EMPTY
        return 0;
    }
	
    memcpy(canMsg, &can_ring_buf[can_i_get], sizeof(TYPE_Can));	
    can_i_get = CAN_INC(can_i_get);
    return 1;
}

u8 recv_can_msg()
{	
	TYPE_Can canMsg;
	while (CAN_GetRingItem(&canMsg) > 0)  // ��ȡcan��������
	{
	//	LOGEln("Recv Can Msg:%08x,%02x,%02x,%02x,%02x,%02x,%02x,%02x,%02x\r\n",
	//		canMsg.id, 
	//		canMsg.data[0], canMsg.data[1], 
	//		canMsg.data[2], canMsg.data[3], 
	//		canMsg.data[4], canMsg.data[5],
	//		canMsg.data[6], canMsg.data[7]);
		deal_can_msg(&canMsg);
	}
	return 1;
}


/*
 * ����can����
 */
void deal_can_msg(TYPE_Can *canMsg)
{
	u32 DataCt[2];
  u32 CanID=0;
  u8  len;
switch(canMsg->id) {
		
		case CAN_MSG_ID_UDS :
/*		LOGEln("Recv Can Msg:%08x,%02x,%02x,%02x,%02x,%02x,%02x,%02x,%02x\r\n",
			canMsg->id, 
			canMsg->data[0], canMsg->data[1], 
			canMsg->data[2], canMsg->data[3], 
			canMsg->data[4], canMsg->data[5],
			canMsg->data[6], canMsg->data[7]);	
*/		
 	  CanID = canMsg->id;
	  len = (uint8_t)canMsg->dlc;
	 
		memcpy(DataCt,canMsg->data,sizeof(canMsg->data));
		  
	//DataCt[0] = (Udsdata[3] << 24) + (Udsdata[2] << 16) + (Udsdata[1] << 8) + (Udsdata[0]);
	//DataCt[1] = (Udsdata[7] << 24) + (Udsdata[6] << 16) + (Udsdata[5] << 8) + (Udsdata[4]);
	//CAN_LOG("CanID: %08x,%02x,%02x,%02x,%02x,%02x,%02x,%02x,%02x \r\n", CanID,
	//Udsdata[0],Udsdata[1] ,Udsdata[2] ,Udsdata[3] ,
	//Udsdata[4],Udsdata[5] ,Udsdata[6] ,Udsdata[7]);
	//CAN_LOG("CanID: %08x, %08x ,%08x\r\n", CanID, DataCt[0] ,DataCt[1]);
	     
		DLIndication(CanID,DataCt,len);
      
		default:break;
	}
}


boolean CAN_RingIsEmpty()
{
	return can_i_get == can_i_put;
}

void CAN_ClearRing()
{
	can_i_get = 0;
    can_i_put = 0;
}


void CAN_RecvFunc(CAN_Channel_t ch, CanRxMsg *RxMessage)
{
	TYPE_Can canMsg;
	memset(&canMsg, 0, sizeof(canMsg));
	
	canMsg.ch = ch;
//	canMsg.timestamp = g_SysTicks;
	if(RxMessage->IDE == CAN_Id_Standard) {
		// ��׼֡
		canMsg.id = RxMessage->StdId;
	} else if(RxMessage->IDE == CAN_Id_Extended) {
		// ��չ֡
		canMsg.id = RxMessage->ExtId;
	} else {
		return;
	}

	canMsg.dlc = RxMessage->DLC;
	memcpy(canMsg.data, RxMessage->Data, canMsg.dlc);
	
	CAN_PutRingItem(&canMsg);
}

void CAN_InitDefault()
{
	CAN_SetupStructure CAN_SetupStructure;
	
	memset(&CAN_SetupStructure, 0, sizeof(CAN_SetupStructure));
	CAN_SetupStructure.bps = CAN1_BPS;
	CAN_SetupStructure.needRemap = TRUE;

#if CAN_HW_FILTER_EN
	memcpy(CAN_SetupStructure.filterStdIds, c_Can1FilterStdIds, sizeof(c_Can1FilterStdIds));
	CAN_SetupStructure.filterStdIdLen = sizeof(c_Can1FilterStdIds) / sizeof(u16);
	memcpy(CAN_SetupStructure.filterExtIds, c_Can1FilterExtIds, sizeof(c_Can1FilterExtIds));
	CAN_SetupStructure.filterExtIdLen = sizeof(c_Can1FilterExtIds) / sizeof(u32);
#endif
	CAN_SetupStructure.recv_func = CAN_RecvFunc;
	CAN1_Config(&CAN_SetupStructure);
	
	memset(&CAN_SetupStructure, 0, sizeof(CAN_SetupStructure));
	CAN_SetupStructure.bps = CAN2_BPS;
	CAN_SetupStructure.needRemap = TRUE;

#if CAN_HW_FILTER_EN
	memcpy(CAN_SetupStructure.filterStdIds, c_Can2FilterStdIds, sizeof(c_Can2FilterStdIds));
	CAN_SetupStructure.filterStdIdLen = sizeof(c_Can2FilterStdIds) / sizeof(u16);
	memcpy(CAN_SetupStructure.filterExtIds, c_Can2FilterExtIds, sizeof(c_Can2FilterExtIds));
	CAN_SetupStructure.filterExtIdLen = sizeof(c_Can2FilterExtIds) / sizeof(u32);
#endif

	CAN_SetupStructure.recv_func = CAN_RecvFunc;
	CAN2_Config(&CAN_SetupStructure);
}


void CAN_Disable()
{
	CAN1_Disable();
	CAN2_Disable();
}

void CAN_Enable()
{
	CAN1_Enable();
	CAN2_Enable();
}

