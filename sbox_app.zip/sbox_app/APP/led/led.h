#ifndef __CHENJUN_LED_H__
#define __CHENJUN_LED_H__

#include "common.h"
#include "time_task.h"

// LED���ƽ�
#define LED1_PORT			GPIOC
#define LED1_PIN			GPIO_Pin_2	
#define LED1_ON()			GPIO_ResetBits(LED1_PORT, LED1_PIN)
#define LED1_OFF()			GPIO_SetBits(LED1_PORT, LED1_PIN)

#define LED2_PORT			GPIOC
#define LED2_PIN			GPIO_Pin_3
#define LED2_ON()			GPIO_ResetBits(LED2_PORT, LED2_PIN)
#define LED2_OFF()			GPIO_SetBits(LED2_PORT, LED2_PIN)


void LED_Init(void);
s32 LED1_Flash(void);
s32 LED2_Flash(void);

void  LED1_SlowFlash(void);
void  LED1_QuickFlash(void);

void  LED2_SlowFlash(void);
void  LED2_QuickFlash(void) ;
#endif

