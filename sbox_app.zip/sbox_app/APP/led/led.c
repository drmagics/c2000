#include "led.h"


/**
 * LED��˸
 */
s32 LED1_Flash()
{
	static u8 count = 0;

	if(count++ % 2) {
		LED1_OFF();
	} else {
		LED1_ON();
	}
	return TASK_FUNC_CONTINUE;
}

s32 LED2_Flash()
{
	static u8 count = 0;

	if(count++ % 2) {
		LED2_OFF();
	} else {
		LED2_ON();
	}
	return TASK_FUNC_CONTINUE;
}


void LED_Init()
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE); //ʹ��PORTBʱ��
	GPIO_InitTypeDef GPIO_InitStructure;	

	// LED�ƿ���
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP ;   //�������
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Pin = LED1_PIN;
	GPIO_Init(LED1_PORT, &GPIO_InitStructure);
	
	// LED�ƿ���
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP ;   //�������
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Pin = LED2_PIN;
	GPIO_Init(LED2_PORT, &GPIO_InitStructure);
	
	
	LED1_QuickFlash();
	LED2_QuickFlash();
}


u8 led1_status = 0;
u8 led2_status = 0;
void  LED1_SlowFlash() 
{
	if(led1_status == 1) {
		return;
	}
	Task_Add(0, 1000, (TimeTaskFunc_t)LED1_Flash, NULL);
	led1_status = 1;
}
void LED1_QuickFlash() 
{
	if(led1_status == 2) {
		return;
	}
	Task_Add(0, 100, (TimeTaskFunc_t)LED1_Flash, NULL);
	led1_status = 2;
}		


void  LED2_SlowFlash() 
{
	if(led2_status == 1) {
		return;
	}
	Task_Add(0, 1000, (TimeTaskFunc_t)LED2_Flash, NULL);
	led2_status = 1;
}

void  LED2_QuickFlash() 
{
	if(led2_status == 2) {
		return;
	}
	Task_Add(0, 100, (TimeTaskFunc_t)LED2_Flash, NULL);
	led2_status = 2;
}







