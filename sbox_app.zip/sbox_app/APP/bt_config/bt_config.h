#ifndef __BT_CONFIG_H__
#define __BT_CONFIG_H__

#include "common.h"

// BT ��Դ����
#define GPIO_BT_PWR_PORT			GPIOC
#define GPIO_BT_PWR_PIN				GPIO_Pin_1
#define GPIO_BT_PWR_ON()			GPIO_ResetBits(GPIO_BT_PWR_PORT, GPIO_BT_PWR_PIN)
#define GPIO_BT_PWR_OFF()			GPIO_SetBits(GPIO_BT_PWR_PORT, GPIO_BT_PWR_PIN)

// BT ״̬�ܽ�
#define GPIO_BT_STA_PORT			GPIOC
#define GPIO_BT_STA_PIN				GPIO_Pin_9

// BT ���ùܽ�
#define GPIO_BT_SET_PORT			GPIOA
#define GPIO_BT_SET_PIN				GPIO_Pin_4
#define GPIO_BT_SET_ON()			GPIO_SetBits(GPIO_BT_SET_PORT, GPIO_BT_SET_PIN)
#define GPIO_BT_SET_OFF()			GPIO_ResetBits(GPIO_BT_SET_PORT, GPIO_BT_SET_PIN)
#define GPIO_BT_SET_STATUS()		GPIO_ReadInputDataBit(GPIO_BT_SET_PORT, GPIO_BT_SET_PIN)

// KEY1 ����
#define GPIO_KEY_PORT				GPIOA
#define GPIO_KEY_PIN				GPIO_Pin_5
#define GPIO_KEY_IS_PRESS()			GPIO_ReadInputDataBit(GPIO_KEY_PORT, GPIO_KEY_PIN) == 1

void BT_Config_Init(void);

#endif
