#include "bt_config.h"
#include "uart.h"
#include "uart_manager.h"
#include "delay.h"
#include "gpio.h"
#include "led.h"

#define BT_CONFIG_UART_BPS		38400

void bt_uart_send_string(char *str)
{
	UART_SendToBt((u8 *)str, (u16)strlen(str));
}

void bt_uart_clear_buff()
{
	UART_Clear_BtBuff();
}

u16 bt_uart_get_data(u8 *dest)
{
	return UART_Get_BtBuff(dest);
}

char at_result_buff[128];
boolean check_at_result(char *check, u32 interval)
{
	u32 delayTime;
	u16 len;
	
	delayTime = g_SysTicks + interval;
	
	memset(at_result_buff, 0, sizeof(at_result_buff));
	while(g_SysTicks < delayTime) {
		delay_ms(100);
		len = bt_uart_get_data((u8 *)at_result_buff);
		
		if(len > 0 && strstr(at_result_buff, check) != NULL) {
			return TRUE;
		} else if(strstr(at_result_buff, "ERROR") != NULL) {
			return FALSE;
		}
	}
	return FALSE;	
}

boolean send_at_command(char *cmd, char *check, u8 wait_times, u32 interval)
{
	u8 i;
	for(i = 0; i < wait_times; i++) {
		bt_uart_clear_buff(); // ��ս���buff
		bt_uart_send_string(cmd);
		
		if(check_at_result(check, interval)) {
			return TRUE;
		}
	}
	
	return FALSE;
}

void BT_Config_Init()
{
	boolean ret;
	
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOC, ENABLE); //ʹ��PORTCʱ��

	// BT ��Դ����
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP ;   //�������
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Pin = GPIO_BT_PWR_PIN;
	GPIO_Init(GPIO_BT_PWR_PORT, &GPIO_InitStructure);
	
		
	// BT ״̬�ܽ�����
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;   //��������
	GPIO_InitStructure.GPIO_Pin = GPIO_BT_STA_PIN;
	GPIO_Init(GPIO_BT_STA_PORT, &GPIO_InitStructure);
	
	EXTI_InitTypeDef EXTI_InitStructure;
	EXTI_InitStructure.EXTI_Line = EXTI_Line9;	//���ð������е��ⲿ��·
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;			//�����ⲿ�ж�ģʽ:EXTI��·Ϊ�ж�����
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising_Falling;//EXTI_Trigger_Rising;  //�����ش���
   	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	EXTI_Init(&EXTI_InitStructure);	// ��ʼ���ⲿ�ж�
	
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = EXTI9_5_IRQn;	
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;	//��ռ���ȼ�1λ,�����ȼ�3λ
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;	//��ռ���ȼ�0λ,�����ȼ�4λ
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;		//ʹ�ܸ�ͨ���ж�
	NVIC_Init(&NVIC_InitStructure);		//����NVIC_InitStruct��ָ���Ĳ�����ʼ������NVIC�Ĵ���
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOC, GPIO_PinSource9);	//�ж���0����GPIOC9
	
	// BT ���ùܽų�ʼ��
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;   //�������
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Pin = GPIO_BT_SET_PIN;
	GPIO_Init(GPIO_BT_SET_PORT, &GPIO_InitStructure);
	GPIO_BT_SET_OFF();
	
	// KEY1 ����
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING ;   //��������
	GPIO_InitStructure.GPIO_Pin = GPIO_KEY_PIN;
	GPIO_Init(GPIO_KEY_PORT, &GPIO_InitStructure);
	
	if(GPIO_KEY_IS_PRESS()) {
		UART_BT_Init(BT_CONFIG_UART_BPS);
RECONFIG:
		// ����������ģ�鲢���������ùܽŴ�
		GPIO_BT_PWR_OFF();
		GPIO_BT_SET_ON();
		LOGDln("bluetooth reboot");
		delay_ms(1000);
		GPIO_BT_PWR_ON();
		delay_ms(1000);
		GPIO_BT_SET_OFF();
		LOGDln("please free the button");
		while(GPIO_KEY_IS_PRESS());		// �ȴ������ͷ�
		GPIO_BT_SET_OFF();
		LOGDln("bluetooth config");
		
		// �������ģ���������
		ret = send_at_command("AT\r\n", "OK", 5, 1000);
		LOGDln("[AT]%s", at_result_buff);
		if(!ret) {
			goto RECONFIG;
		}
		
		// ����Ϊ��ģʽ
		ret = send_at_command("AT+ROLE=0\r\n", "OK", 2, 500);
		LOGDln("[AT+ROLE=0]%s", at_result_buff);
		if(!ret) {
			goto RECONFIG;
		}
			
		// ���ô��ڲ�����
		ret = send_at_command("AT+UART=460800,0,0\r\n", "OK", 2, 500);
		LOGDln("[AT+UART...]%s", at_result_buff);
		if(!ret) {
			goto RECONFIG;
		}
					
		// ��ȡ����ģ���ַ
		ret = send_at_command("AT+ADDR?\r\n", "OK", 2, 500);
		LOGDln("[AT+ADDR?]%s", at_result_buff);
		if(!ret) {
			goto RECONFIG;
		}
		char *addr = strstr(at_result_buff, "+ADDR:");
		if(addr == NULL) {
			goto RECONFIG;
		}
		addr = strtok(addr, ":");
		addr = strtok(NULL, ":");
		addr = strtok(NULL, ":");
		addr = strtok(NULL, ":");
		addr += 2;
		
		u16 pwd = 0;
		pwd += ((u16)char2Hex(addr[0])) << 12;
		pwd += ((u16)char2Hex(addr[1])) << 8;
		pwd += ((u16)char2Hex(addr[2])) << 4;
		pwd += ((u16)char2Hex(addr[3]));
		pwd = pwd % 10000;
		
		// ������������
		char hc05_name[30] = "AT+NAME=sBox-";
		strncat(hc05_name, addr, 4);
		strcat(hc05_name, "\r\n");
		ret = send_at_command(hc05_name, "OK", 3, 500);
		LOGDln("[%s]%s", hc05_name, at_result_buff);
		if(!ret) {
			goto RECONFIG;
		}
	
		// �����������
		char hc05_pwd[30] = "AT+PSWD=0000\r\n";
		hc05_pwd[8] = pwd / 1000 + '0';
		hc05_pwd[9] = pwd / 100 % 10 + '0';
		hc05_pwd[10] = pwd / 10 % 10 + '0';
		hc05_pwd[11] = pwd % 10 + '0';
		send_at_command(hc05_pwd, "OK", 3, 500);
		LOGDln("[%s]%s", hc05_pwd, at_result_buff);
		if(!ret) {
			goto RECONFIG;
		}
		
		GPIO_BT_PWR_OFF();
		delay_ms(1000);
	}
	GPIO_BT_PWR_ON();
	
}


