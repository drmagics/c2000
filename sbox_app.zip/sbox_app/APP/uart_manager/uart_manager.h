#ifndef __UART_MANGER_H__
#define __UART_MANGER_H__

#include "common.h"
#include "uart.h"

typedef enum {
	UART1_CHANNEL = 0,
	UART2_CHANNEL = 1,
	UART3_CHANNEL = 2,
} UART_CHANNEL_t;


void UART_DEBUG_Init(u32 bps);

void UART_BT_Init(u32 bps);

void UART_SendToBt(u8 *data, u16 len);

void UART_Clear_BtBuff(void);

u16 UART_Get_BtBuff(u8 *data);
















#endif
