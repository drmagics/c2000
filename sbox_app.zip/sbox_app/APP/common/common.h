#ifndef __CHENJUN_COMMON_H__
#define __CHENJUN_COMMON_H__

#include "stm32f10x.h"
#include "stdio.h"
#include "string.h"
#include "stdlib.h"
#include "type.h"
#include "config.h"

//******************************************************************
#define TRUE		1
#define FALSE		0
//******************************************************************

#define STR1(R)  #R
#define STR2(R)  STR1(R)			// ���ֺ�ת�ַ�����

//******************************************************************
//						 log���
//******************************************************************
#define LOG_DEBUG_SWITCH	 	1			//��־����

#if LOG_DEBUG_SWITCH
	#define LOGD(fmt, x...)		printf(fmt, ##x)
#else
	#define LOGD(fmt, x...)	
#endif

#define LOGE(fmt, x...)		printf(fmt, ##x)

#define LOGDln(fmt, x...)		LOGD(fmt"\r\n", ##x)
#define LOGEln(fmt, x...)		LOGE(fmt"\r\n", ##x)

//******************************************************************
#define COMMON_HEADER_START_TAG		0x2323

//******************************************************************
//						 ��С��
//******************************************************************
// STM32 Ĭ���Ǵ��ģʽ
#define IS_BIG_ENDIAN 0
#if IS_BIG_ENDIAN
	#define BigLittleSwap16(A) 		A
	#define BigLittleSwap32(A) 		A
#else
	#define BigLittleSwap16(A)  ((((u16)(A) & 0xff00) >> 8) | \
								(((u16)(A) & 0x00ff) << 8))

	#define BigLittleSwap32(A)  ((((u32)(A) & 0xff000000) >> 24) | \
								(((u32)(A) & 0x00ff0000) >> 8) | \
								(((u32)(A) & 0x0000ff00) << 8) | \
								(((u32)(A) & 0x000000ff) << 24))							
#endif
//******************************************************************


#define GET_1BIT(d, x)			(((d) >> (x)) & 0x01)
#define GET_1BYTE(d, x) 		(((d) >> ((x) * 8)) & 0xFF)


// ȡ����ֵ
#define ABS(x)					((x) > 0 ? (x) : -(x))
// �������������ȡ����ֵ
#define ABS_DIFF(x, y)			((x) > (y) ? (x) - (y) : (y) - (x))


void printArray(const u8 *array, u16 size);
u8 calcCrc(u8 *buffer, u16 offset, u16 length);
u8 char2Hex(char ch);
#endif


