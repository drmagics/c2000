#include "common.h"

void printArray(const u8 *array, u16 size)
{
	u16 i;
	for(i = 0; i < size; i++) {
		LOGD("%02x ", array[i]);
	}
	LOGDln();
}

u8 calcCrc(u8 *buffer, u16 offset, u16 length)
{
    u8  bcc_check = 0;
    u16 i = 0;
	
	for(i = 0; i < length; i++) {
		bcc_check ^= buffer[i + offset];
	}
    return bcc_check;
}

u8 char2Hex(char ch)
{
	if('0' <= ch && ch <= '9') {
		return ch - '0';
	} else if('A' <= ch && ch <= 'F') {
		return ch - 'A';
	} else if('a' <= ch && ch <= 'f') {
		return ch - 'a';
	}
	return 0;
}


