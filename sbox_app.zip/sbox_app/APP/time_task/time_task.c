#include "time_task.h"
#include "delay.h"

#define TIME_MIN_UNIT				1					// ��ʱ����С��λ10ms
TimeTask_t g_TimeTaskBuf[TASK_MAX_COUNT];

void Task_Exec()
{
	static u32 lastTimerTicks = 0;
	u8 i;
	u32 time;
	TimeTask_t	*pTimeTask;
	
	if(lastTimerTicks == g_SysTicks) {
		return;
	}
	
	lastTimerTicks = g_SysTicks;
	for(i = 0; i < TASK_MAX_COUNT; i++) 
	{
		pTimeTask = &g_TimeTaskBuf[i];
		if(pTimeTask->isUsed) {
			time = g_SysTicks - pTimeTask->start;
			if(pTimeTask->delay > 0 && time >= pTimeTask->delay) {
				pTimeTask->delay = 0;
				pTimeTask->taskFunc(pTimeTask);
				continue;
			}
			if(pTimeTask->delay == 0 && time % pTimeTask->interval == 0) {
				pTimeTask->taskFunc(pTimeTask);
			}
		}
	}
}

int Task_Add(u32 delay, u32 interval, TimeTaskFunc_t taskFunc, void *args)
{
	u8 i;
	TimeTask_t	*pTimeTask;
	Task_RemoveByFunc(taskFunc);
	
	for(i = 0; i < TASK_MAX_COUNT; i++)
	{
		pTimeTask = &g_TimeTaskBuf[i];
		if(!pTimeTask->isUsed) {
			pTimeTask->isUsed	= TRUE;
			pTimeTask->start	= g_SysTicks;
			pTimeTask->delay	= delay / TIME_MIN_UNIT;
			pTimeTask->interval	= interval / TIME_MIN_UNIT;
			pTimeTask->taskFunc	= taskFunc;
			pTimeTask->args		= args;
			return i;
		}
	}
	return -1;
}

void Task_Modif(TimeTaskFunc_t taskFunc, u32 interval)
{
	u8 i;
	TimeTask_t	*pTimeTask;
	for(i = 0; i < TASK_MAX_COUNT; i++)
	{
		pTimeTask = &g_TimeTaskBuf[i];
		if(pTimeTask->isUsed && pTimeTask->taskFunc == taskFunc) {
			pTimeTask->start = g_SysTicks;
			pTimeTask->interval	= interval / TIME_MIN_UNIT;
			break;
		}
	}
}

void Task_RemoveById(int tid)
{
	TimeTask_t	*pTimeTask = &g_TimeTaskBuf[tid];
	if(pTimeTask->isUsed) {
		memset(pTimeTask, 0, sizeof(TimeTask_t));
	}
}

void Task_RemoveByFunc(TimeTaskFunc_t taskFunc)
{
	u8 i;
	TimeTask_t	*pTimeTask;
	for(i = 0; i < TASK_MAX_COUNT; i++)
	{
		pTimeTask = &g_TimeTaskBuf[i];
		if(pTimeTask->isUsed && pTimeTask->taskFunc == taskFunc) {
			memset(pTimeTask, 0, sizeof(TimeTask_t));
			break;
		}
	}
}
