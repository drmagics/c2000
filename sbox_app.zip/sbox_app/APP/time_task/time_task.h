#ifndef __TIME_TASK_H__
#define __TIME_TASK_H__

#include "common.h"

#define TASK_FUNC_CONTINUE		0
#define TASK_FUNC_FINISH		1

#define TASK_MAX_COUNT			20



typedef struct _TimeTask_t{
	boolean	isUsed;
	boolean needExec;
	u32		start;
	u32		delay;
	u32		interval;
	s32 	(*taskFunc)(struct _TimeTask_t *);
	void	*args;
} TimeTask_t;
typedef s32 	(*TimeTaskFunc_t)(TimeTask_t *);

void Task_Init(void);

void Task_Exec(void);

int Task_Add(u32 delay, u32 interval, TimeTaskFunc_t taskFunc, void *args);

void Task_RemoveById(int tid);

void Task_RemoveByFunc(TimeTaskFunc_t taskFunc);

void Task_Modif(TimeTaskFunc_t taskFunc, u32 interval);













#endif
