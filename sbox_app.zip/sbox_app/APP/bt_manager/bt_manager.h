#ifndef __BT_MANAGE_H__
#define __BT_MANAGE_H__

#include "common.h"
#include "bt_config.h"


// ͨ����Ϣͷ

#define UART_MAX_DATA_SIZE		255
#define UART_BUFF_SIZE		(sizeof(TYPE_CommonHeader) + MSG_UART_MAX_DATA_SIZE + 1)


typedef enum {
	    BT_TYPE_HEARTBEAT = 0x00,
	    BT_TYPE_CAN = 0x01,
		BT_TYPE_CCP = 0x02,
		BT_ACK_CCP = 0xF2,
		
		BT_TYPE_CCP_CONFIG = 0x03,
		BT_ACK_CCP_CONFIG = 0xF3,
			
		BT_TYPE_UPDATE = 0x07,
		BT_ACK_UPDATE = 0xF7,
	
	    BT_TYPE_UDS = 0x0A,
	    BT_TYPE_VIN_READ = 0x0B,
		BT_TYPE_VIN_WRITE = 0x0C,
		BT_ACK_VIN_WRITE = 0xFC,
	
		BT_TYPE_TROUBLE = 0x0D,
		BT_ACK_TROUBLE = 0xFD,
	
		BT_TYPE_UDS_UPGRADE = 0x0E,
		BT_ACK_UDS_UPGRADE = 0xFE,

} bt_type_enum_t; 

typedef struct {
	u32 canId;
	TYPE_Can canPkg;
	u32 lastSendTimestamp;
	
	boolean isUpdate;
} bt_can_pkg_t;


#define MAX_CAN_PKG_COUNT 		150


extern bt_can_pkg_t g_BtCanPkgs[MAX_CAN_PKG_COUNT];
extern u8 g_BtCanPkgCount;

#define BT_IS_CONNECT()		GPIO_ReadInputDataBit(GPIO_BT_STA_PORT, GPIO_BT_STA_PIN) == 1

void BT_SendMsg(u8 command, void *data, u8 len);
void BT_SendMsgWithHead(u8 command, void *subHeader, u8 subHeaderLen, void *data, u8 len);
void BT_SendCanMsg(TYPE_Can canMsgs[], u8 len);
void BT_SendAckMsg(u8 type, u8 isSuccess);

u16  BT_RecvMsg(u8 *buf);







#endif
