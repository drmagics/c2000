#include "bt_manager.h"
#include "uart_manager.h"

extern u32 g_SysTicks;
 u8 g_MsgUartSendBuff[UART_MAX_DATA_SIZE];

bt_can_pkg_t g_BtCanPkgs[MAX_CAN_PKG_COUNT];
u8 g_BtCanPkgCount = 0;


/**
 *	������BTģ�鷢����Ϣ
 */
void BT_SendMsg(u8 command, void *data, u8 len)
{
	if(!BT_IS_CONNECT()) {
		return;
	}
	TYPE_CommonHeader *header = (TYPE_CommonHeader *)g_MsgUartSendBuff;
	header->startTag 	= COMMON_HEADER_START_TAG;
	header->cmd 		= command;
	header->len			= len;
	if(header->len + sizeof(TYPE_CommonHeader) + 1 >= sizeof(g_MsgUartSendBuff)) {
		return;
	}
	
	memcpy(&g_MsgUartSendBuff[sizeof(TYPE_CommonHeader)], data, len);
	
	g_MsgUartSendBuff[sizeof(TYPE_CommonHeader) + len] = calcCrc(g_MsgUartSendBuff, 0, sizeof(TYPE_CommonHeader) + len);
	
	UART_SendToBt(g_MsgUartSendBuff, sizeof(TYPE_CommonHeader) + len + 1);
}

void BT_SendMsgWithHead(u8 command, void *subHeader, u8 subHeaderLen, void *data, u8 len)
{
	if(!BT_IS_CONNECT()) {
		return;
	}
	TYPE_CommonHeader *header = (TYPE_CommonHeader *)g_MsgUartSendBuff;
	header->startTag 	= COMMON_HEADER_START_TAG;
	header->cmd 		= command;
	header->len			= subHeaderLen + len;
	if(sizeof(TYPE_CommonHeader) + header->len + 1 >= sizeof(g_MsgUartSendBuff)) {
		return;
	}
	
	if(subHeader != NULL && subHeaderLen > 0) {
		memcpy(&g_MsgUartSendBuff[sizeof(TYPE_CommonHeader)], subHeader, subHeaderLen);
	}
	if(data != NULL && len > 0) {
		memcpy(&g_MsgUartSendBuff[sizeof(TYPE_CommonHeader) + subHeaderLen], data, len);
	}
	
	g_MsgUartSendBuff[sizeof(TYPE_CommonHeader) + header->len] = calcCrc(g_MsgUartSendBuff, 0, sizeof(TYPE_CommonHeader) + header->len);
	
	UART_SendToBt(g_MsgUartSendBuff, sizeof(TYPE_CommonHeader) + header->len + 1);
}

/**
 *	����������ģ�鷢��CAN��Ϣ
 */
void BT_SendCanMsg(TYPE_Can canMsgs[], u8 len)
{
	u8 i;

	for(i = 0; i < len; i++) {
		canMsgs[i].id = BigLittleSwap32(canMsgs[i].id);
	}
	BT_SendMsg(BT_TYPE_CAN, canMsgs, sizeof(TYPE_Can) * len);
}

void BT_SendAckMsg(u8 type, u8 isSuccess)
{
	u8 data[1];
	data[0] = isSuccess ? 1 : 0;
	BT_SendMsg(type, data, 1);
}

u16 BT_RecvMsg(u8 *buf)
{
	return UART_Get_BtBuff(buf);
}

#include "LED.h"

void EXTI9_5_IRQHandler(void)
{
	EXTI_ClearITPendingBit(EXTI_Line9);
	u8 i = 0;
	for(i = 0; i < MAX_CAN_PKG_COUNT; i++) {
		g_BtCanPkgs[i].lastSendTimestamp = g_SysTicks + 500;
		g_BtCanPkgs[i].isUpdate = FALSE;
	}
	
	if(BT_IS_CONNECT()) {
		LED2_SlowFlash();
	} else {
		LED2_QuickFlash();
	}
	
	g_BtCanPkgCount = 0;
}

