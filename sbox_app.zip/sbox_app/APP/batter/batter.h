#ifndef __BATTER_H__
#define __BATTER_H__

#include "common.h"



void BATTER_Init(void);










#endif

