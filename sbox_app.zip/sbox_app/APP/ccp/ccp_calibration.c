#include <stdio.h>
#include <string.h>
#include "ccp.h"
#include "can_manager.h"
#include "delay.h"


//****************************************************************************
/**
 * ����궨����
 */
#define _DEBUG_CAL_ 1
extern void ccp_cal_short_up(void);
extern void ccp_cal_recv(u8 backMsg[]);
extern void send_mc20_cal_msg(u16 startAddr, u16 totalLen);
u8 ccp_request_cal()
{
	if(!ccp_is_free()) {
		return 0;
	}
	if(!ccp_is_connected()) {
		ccp_task_flag |= BLE_CCP_CMD_CONNECT;
		return 0;
	}
	
	ccp_status = CCP_STATUS_REQUSET_CAL;
	ccp_task.sizeCount = 0;
	ccp_cal_short_up();
	LOGDln("start request cal");
	return 1;
}

void ccp_cal_short_up()
{
	u16 leftSize = ccp_task.totalSize - ccp_task.sizeCount;
	u8 size = leftSize > 5 ? 5 : leftSize;
	u32 addr = CCP_CAL_BASE_ADDR + 
		ccp_task.addr + ccp_task.sizeCount;
	
	memset(ccp_task.data, 0, 8);
	ccp_task.data[0] = CCP_CMD_SHORT_UP;
	ccp_task.data[1] = CCP_COUNT_INC();
	ccp_task.data[2] = size;
	ccp_task.data[3] = 0;
	ccp_task.data[4] = (addr >> 24) & 0xFF;
	ccp_task.data[5] = (addr >> 16) & 0xFF;
	ccp_task.data[6] = (addr >> 8)  & 0xFF;
	ccp_task.data[7] = (addr >> 0)  & 0xFF;
	
	ccp_task.dealSize 	= ccp_task.data[2];
	ccp_task.callBack 	= ccp_cal_recv;

	ccp_send_msg(ccp_task.data);	
	#if _DEBUG_CAL_
		LOGDln("ccp_cal_short_up(cnt:%d, addr:%d)", ccp_task.data[1], addr);
	#endif
}

void ccp_cal_recv(u8 backMsg[])
{
	if(ccp_task.data[0] != CCP_CMD_SHORT_UP) {
		return ;
	}
		
	memcpy(&ccp_buff[ccp_task.addr + ccp_task.sizeCount], &backMsg[3], 
		ccp_task.dealSize);
	ccp_task.sizeCount += ccp_task.dealSize;
	
	if(ccp_task.sizeCount < ccp_task.totalSize) {
		// ���ݻ�δ������ɣ���������궨����
		ccp_cal_short_up();
	} else {
		// �������
		LOGDln("ccp recv cal datas success, len:%d", ccp_task.sizeCount);
		send_mc20_cal_msg(ccp_task.addr, ccp_task.totalSize);
		LOGDln("send cal msg to ble success\r\n");
		ccp_status = CCP_STATUS_FREE;
		#if _DEBUG_CAL_
			printArray(ccp_buff, ccp_task.sizeCount);
		#endif
	}
}

void send_mc20_cal_msg(u16 startAddr, u16 totalLen)
{	
	u16 sendMaxLen = BLE_MSG_MAX_SEND_LEN - sizeof(ccp_head);
	u16 sendLen;
	
	do {
		sendLen = totalLen > sendMaxLen ? sendMaxLen : totalLen;
		ccp_head.cmd = BLE_CCP_CMD_CAL_REQUEST;
		ccp_head.ack = CCP_ACK_RIGHT;
		ccp_head.addr = BigLittleSwap16(startAddr);
		ccp_head.len = BigLittleSwap16(sendLen);
		ble_send_with_head(BLE_CMD_CCP_MSG, (u8 *)&ccp_head, sizeof(ccp_head), &ccp_buff[startAddr], sendLen);
		LOGDln("send %d bytes of cal msg to ble", sendLen);
		totalLen -= sendLen;
		startAddr += sendLen;
	} while(totalLen > 0);
	
}
//****************************************************************************
/**
 * ���ñ궨����
 */
extern void ccp_set_mta(void);
extern u8 ccp_download(u8 backMsg[]);
extern u8 ccp_download_callback(u8 backMsg[]);
u8 ccp_set_cal()
{
	if(!ccp_is_free()) {
		return 0;
	}
	if(!ccp_is_connected()) {
		ccp_task_flag |= BLE_CCP_CMD_CONNECT;
		return 0;
	}
	ccp_status = CCP_STATUS_SET_CAL;
	LOGDln("start set mark data:%d", ccp_task.totalSize);
	ccp_task.sizeCount = 0;
	ccp_set_mta();
	
	return 1;	
}

void ccp_set_mta() 
{
	u32 addr = CCP_CAL_BASE_ADDR + 
		ccp_task.addr + ccp_task.sizeCount;
	
	memset(ccp_task.data, 0, 8);
	ccp_task.data[0] = CCP_CMD_SET_MTA;
	ccp_task.data[1] = CCP_COUNT_INC();
	ccp_task.data[2] = 0;
	ccp_task.data[3] = 0;
	ccp_task.data[4] = (addr >> 24) & 0xFF;
	ccp_task.data[5] = (addr >> 16) & 0xFF;
	ccp_task.data[6] = (addr >> 8)  & 0xFF;
	ccp_task.data[7] = (addr >> 0)  & 0xFF;
	
	ccp_task.callBack = (void (*)())ccp_download;

	ccp_send_msg(ccp_task.data);
	#if _DEBUG_CAL_
		LOGDln("ccp_set_mta");
	#endif
}

u8 ccp_download(u8 backMsg[])
{
	if(ccp_task.data[0] != CCP_CMD_SET_MTA) {
		return 0;
	}
	u8 leftSize = ccp_task.totalSize - ccp_task.sizeCount;
	u8 sendSize = leftSize > 5 ? 5 : leftSize;
	
	memset(ccp_task.data, 0, 8);
	ccp_task.data[0] = CCP_CMD_DOWNLOAD;
	ccp_task.data[1] = CCP_COUNT_INC();
	ccp_task.data[2] = sendSize;
	
	memcpy(&ccp_task.data[3], &ccp_buff[ccp_task.sizeCount], sendSize);
	
	ccp_task.dealSize = ccp_task.data[2];
	ccp_task.callBack = (void (*)())ccp_download_callback;

	ccp_send_msg(ccp_task.data);
	#if _DEBUG_CAL_
		LOGDln("ccp_download, %d", sendSize);
	#endif
	return 1;
}

u8 ccp_download_callback(u8 backMsg[])
{
	if(ccp_task.data[0] != CCP_CMD_DOWNLOAD) {
		return 0;
	}
				
	ccp_task.sizeCount += ccp_task.dealSize;
	
	if(ccp_task.sizeCount < ccp_task.totalSize) {
		// ����δ��ɣ���������
		ccp_set_mta();
	} else {
		ccp_head.cmd = BLE_CCP_CMD_CAL_SET;
		ccp_head.ack = 1;
		ble_send(BLE_CMD_CCP_MSG, (u8 *)&ccp_head, 2);
		ccp_status = CCP_STATUS_FREE;
		ccp_task.addr = ccp_task.addr;
		ccp_task.totalSize = ccp_task.totalSize;
		ccp_request_cal();
		LOGDln("set cal data success");
	}
	
	return 1;
}
//****************************************************************************
/**
 * ����궨����
 */
extern u8 ccp_store_cal_callback(u8 backMsg[]);
u8 ccp_store_cal()
{
	if(!ccp_is_free()) {
		return 0;
	}
	if(!ccp_is_connected()) {
		ccp_task_flag |= BLE_CCP_CMD_CONNECT;
		return 0;
	}
	ccp_status = CCP_STATUS_STORE;
	
	memset(ccp_task.data, 0, 8);
	ccp_task.data[0] = CCP_CMD_SET_S_STATUS;
	ccp_task.data[1] = CCP_COUNT_INC();
	ccp_task.data[2] = (1 << 6);
	
	ccp_task.callBack = (void (*)(u8 *))ccp_store_cal_callback;
	
	ccp_send_msg(ccp_task.data);
	LOGDln("start store calibration datas");
	return 1;
}

u8 ccp_store_cal_callback(u8 backMsg[])
{
	u8 isSuccess = backMsg[1] == 0x00;
	
	ccp_head.cmd = BLE_CCP_CMD_CAL_STORE;
	ccp_head.ack = isSuccess ? CCP_ACK_RIGHT : CCP_ACK_ERROR;
	ble_send(BLE_CMD_CCP_MSG, (u8 *)&ccp_head, 2);
	ccp_status = CCP_STATUS_FREE;
	ccp_connect_status = CONNECT_STATUS_DISCONNECT;
	LOGDln("store calibration datas %s", isSuccess ? "success" : "failed");
	return 1;
}

