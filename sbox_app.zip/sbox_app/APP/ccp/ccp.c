#include <stdio.h>
#include <string.h>
#include "ccp.h"
#include "can_manager.h"
#include "delay.h"



u8 ccp_task_flag;

u8 ccp_buff[CCP_BUFF_LEN];

u8 ccp_status = CCP_STATUS_FREE;
u8 ccp_connect_status = CONNECT_STATUS_DISCONNECT;		//  ccp����״̬
u8 ccp_monitor_status = MONITOR_STATUS_NOPREPARE; 		// �������״̬

ccp_task_t ccp_task;

ccp_head_t ccp_head;

/**
 * ����ccp����
 */
void exec_ccp_task()
{
	if(ccp_task_flag & BLE_CCP_CMD_CONNECT
		&& ccp_connect()) {
		ccp_task_flag &= ~BLE_CCP_CMD_CONNECT;
	}
	
	if(ccp_task_flag & BLE_CCP_CMD_MONITOR_INIT
		&& ccp_init_monitor()) {
		ccp_task_flag &= ~BLE_CCP_CMD_MONITOR_INIT;
	}
	
	if(ccp_task_flag & BLE_CCP_CMD_MONITOR_REQUEST
		&& ccp_request_monitor()) { 		// ����������	
		ccp_task_flag &= ~BLE_CCP_CMD_MONITOR_REQUEST; 	// ����һ�κ���ձ�־λ
	} 
	
	if(ccp_task_flag & BLE_CCP_CMD_CAL_REQUEST 
		&& ccp_request_cal()) {			// ����궨����	
		ccp_task_flag &= ~BLE_CCP_CMD_CAL_REQUEST;
	}
	
	if(ccp_task_flag & BLE_CCP_CMD_CAL_SET
		&& ccp_set_cal()) {			// ���ñ궨����	
		ccp_task_flag &= ~BLE_CCP_CMD_CAL_SET;
	}
	
	if(ccp_task_flag & BLE_CCP_CMD_CAL_STORE
		&& ccp_store_cal()) {		// ����궨����	
		ccp_task_flag &= ~BLE_CCP_CMD_CAL_STORE;
	}
		
	ccp_deal_timeout();
	ccp_deal_disconnect();
}


u8 ccp_is_disconnected() {
	return ccp_connect_status == CONNECT_STATUS_DISCONNECT;
}

u8 ccp_is_connected() {
	return ccp_connect_status == CONNECT_STATUS_CONNECTED;
}

u8 ccp_is_monitor_prepared() {
	return ccp_monitor_status == MONITOR_STATUS_PREPARED;
}

void ccp_free()
{
	ccp_status = CCP_STATUS_FREE;
}

u8 ccp_is_free()
{
	return ccp_status == CCP_STATUS_FREE;
}

u8 CCP_COUNT_INC()
{
	static u8 ccpCount = 0;
	return ++ccpCount;
}

u8 ccp_send_msg(u8 data[])
{

	can_send_msg(CAN_MSG_ID_CCP_CMD, 8, data);
	
	#if 0
	LOG("Send Can Msg:%02x,%02x,%02x,%02x,%02x,%02x,%02x,%02x\r\n",
		data[0], 
		data[1], 
		data[2], 
		data[3], 
		data[4], 
		data[5], 
		data[6], 
		data[7]
	);
	#endif


	// ��ʱʱ��500ms
	ccp_task.timer = timer_10ms + CCP_TIMEOUT; 
	
	return data[1];
}


void ccp_do_connect(void (*callBack)(u8 *))
{
	memset(ccp_task.data, 0, 8);
	ccp_task.data[0] = CCP_CMD_CONNECT;
	ccp_task.data[1] = CCP_COUNT_INC();
	ccp_task.data[2] = (CCP_STATION_ADDRESS >> 8) & 0xFF;
	ccp_task.data[3] = (CCP_STATION_ADDRESS >> 0) & 0xFF;
	
	ccp_task.callBack = callBack;
}

void ccp_do_short_up(u8 size, u32 addr, void (*callBack)(u8 *))
{
	memset(ccp_task.data, 0, 8);
	ccp_task.data[0] = CCP_CMD_SHORT_UP;
	ccp_task.data[1] = CCP_COUNT_INC();
	ccp_task.data[2] = size;
	ccp_task.data[3] = 0;
	ccp_task.data[4] = (addr >> 24) & 0xFF;
	ccp_task.data[5] = (addr >> 16) & 0xFF;
	ccp_task.data[6] = (addr >> 8)  & 0xFF;
	ccp_task.data[7] = (addr >> 0)  & 0xFF;
	
	ccp_task.dealSize 	= ccp_task.data[2];
	ccp_task.callBack 	= callBack;

	ccp_send_msg(ccp_task.data);	
}

// ����ble���ݸ�ʽ
//struct ccp_mc20_msg_t {
//	StdMsgHeader stdHeader;
//	ccp_mc20_cmd_t ccpHeader;
//	u8 data[N];
//}

//****************************************************************************


/**
 * ��ble ���ʹ�����Ϣ
 */
void send_ble_error_msg()
{
	switch(ccp_status) {
		case CCP_STATUS_CONECTING:
			ccp_head.cmd = BLE_CCP_CMD_CONNECT;
			ccp_head.ack = CCP_ACK_ERROR;
			ble_send(BLE_CMD_CCP_MSG, (u8 *)&ccp_head, 2);
			break;
		
		case CCP_STATUS_INIT_MONITOR:
			ccp_head.cmd = BLE_CCP_CMD_MONITOR_INIT;
			ccp_head.ack = CCP_ACK_ERROR;
			ble_send(BLE_CMD_CCP_MSG, (u8 *)&ccp_head, 2);
			break;
		
		case CCP_STATUS_REQUEST_MONITOR:
		case CCP_STATUS_RECV_MONITOR:		
			ccp_head.cmd = BLE_CCP_CMD_MONITOR_REQUEST;
			ccp_head.ack = CCP_ACK_ERROR;
			ble_send(BLE_CMD_CCP_MSG, (u8 *)&ccp_head, 2);
			break;
		
		case CCP_STATUS_REQUSET_CAL:
			ccp_head.cmd = BLE_CCP_CMD_CAL_REQUEST;
			ccp_head.ack = CCP_ACK_ERROR;
			ble_send(BLE_CMD_CCP_MSG, (u8 *)&ccp_head, 2);
			break;
		
		case CCP_STATUS_SET_CAL:
			ccp_head.cmd = BLE_CCP_CMD_CAL_SET;
			ccp_head.ack = CCP_ACK_ERROR;
			ble_send(BLE_CMD_CCP_MSG, (u8 *)&ccp_head, 2);
			break;
		
		case CCP_STATUS_STORE:
			ccp_head.cmd = BLE_CCP_CMD_CAL_STORE;
			ccp_head.ack = CCP_ACK_ERROR;
			ble_send(BLE_CMD_CCP_MSG, (u8 *)&ccp_head, 2);
			break;
		
		
		default:
			break;
	}
}

/**
 *	ccp����ʱ����
 */
void ccp_deal_timeout()
{
	if(ccp_is_free()) {
		return ;
	}
	
	if(ccp_task.timeoutCount >= 3) {
		
		LOG("ccp exec timeout:0x%02x\r\n", ccp_task.data[0]);
		ccp_connect_status = CONNECT_STATUS_DISCONNECT;
		ccp_task.timeoutCount = 0;
		ccp_task_flag = 0;
		send_ble_error_msg();
			ccp_free();
		
	} else if(ccp_task.timer < timer_10ms) {
		if(ccp_status == CCP_STATUS_RECV_MONITOR) {
			ccp_free();
			ccp_monitor_status = MONITOR_STATUS_NOPREPARE;
			ccp_task.timeoutCount = 0;
			
			LOG("ccp monitor recv timeout\r\n");
		} else {
			ccp_task.timeoutCount++;
			LOG("ccp timeout %d times, resend:0x%02x\r\n", ccp_task.timeoutCount, ccp_task.data[0]);
			ccp_send_msg(ccp_task.data);
		}
	}
	

}
/**
 *	ccp����Ͽ�����
 */
#define  CCP_DISCONNECT_TIME 100   // 1000msû��ccp������Ͽ�ccp����
extern u8 ccp_disconnect_callback(u8 backMsg[]);
void ccp_deal_disconnect()
{
	static u32 ccp_free_timer = 0;
	if(!ccp_is_free()) {
		ccp_free_timer = timer_10ms + CCP_DISCONNECT_TIME;
		return ;
	}
	
	if(ccp_is_connected() && ccp_free_timer < timer_10ms) {
		
		memset(ccp_task.data, 0, 8);
		ccp_task.data[0] = CCP_CMD_DISCONNECT;
		ccp_task.data[1] = CCP_COUNT_INC();
		ccp_task.data[2] = 0x00; // 0x00 ��ʾ��ʱ�Ͽ���0x01 ��ʾ�����Ự
		ccp_task.data[3] = (CCP_STATION_ADDRESS >> 8) & 0xFF;
		ccp_task.data[4] = (CCP_STATION_ADDRESS >> 0) & 0xFF;
		
		ccp_task.callBack 	= (void (*)())ccp_disconnect_callback;
		
		ccp_send_msg(ccp_task.data);
		ccp_connect_status = CONNECT_STATUS_DISCONNECT;
	}
}
u8 ccp_disconnect_callback(u8 backMsg[])
{
	if(backMsg[1] == 0x00) {
		LOG("ccp disconnect success\r\n");
		return 1;
	} else {
		LOG("ccp disconnect failed\r\n");
		return 0;
	}
}

//****************************************************************************
/**
 * ����can���ϵ�CCP����
 */
void deal_ccp_msg(CanRxMsg *ccpMsg)
{
	u8 isRightMsg = 0;
	if(ccpMsg->Data[0] == 0xFF && ccpMsg->Data[2] == ccp_task.data[1]) {
		if(ccpMsg->Data[1] != 0x00) {
			send_ble_error_msg();
			ccp_free();
			return ;
		}
		isRightMsg = 1;
	}
	
	if(isRightMsg 
		|| (ccp_status == CCP_STATUS_RECV_MONITOR && ccpMsg->Data[0] != 0xFF)) {
					
		if(ccp_task.callBack != NULL) {
			ccp_task.callBack(ccpMsg->Data);
		}
		ccp_task.timeoutCount = 0;
		ccp_task.timer = timer_10ms + CCP_TIMEOUT; 
	} 

}








