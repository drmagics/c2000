#ifndef __CCP_H__
#define __CCP_H__

#include "common.h"

#define CCP_CMD_NULL				0xFF

#define CCP_CMD_INIT				0x00
#define CCP_CMD_CONNECT 			0x01
#define CCP_CMD_GET_VERSION 		0x1B
#define CCP_CMD_EXCHANGE_ID			0x17
#define CCP_CMD_GET_SEED			0x12
#define CCP_CMD_UNLOCK 				0x13
#define CCP_CMD_SELECT_CAL_PAGE		0x11
#define CCP_CMD_UPLOAD				0x04
#define CCP_CMD_SHORT_UP			0x0F
#define CCP_CMD_SET_MTA 			0x02
#define CCP_CMD_DOWNLOAD			0x03
#define CCP_CMD_SET_S_STATUS		0x0C
#define CCP_CMD_DISCONNECT			0x07

#define CCP_CMD_INIT_DAQ			0x00
#define CCP_CMD_GET_DAQ_SIZE		0x14
#define CCP_CMD_SET_DAQ_PTR			0x15
#define CCP_CMD_WRITE_DAQ			0x16
#define CCP_CMD_START_STOP_DAQ		0x06


#define CCP_STATION_ADDRESS		25
#define CCP_KEY					0x15987628
#define CCP_TIMEOUT 			5				// 5 * 10 = 50ms
#define CCP_TRY_TIMES			3
#define CCP_MONITOR_BASE_ADDR	0x40016800
#define CCP_CAL_BASE_ADDR		0x40011800

#define CCP_ACK_OK				0x00
#define CCP_ACK_ACCESS_DENIED	0x33
#define CCP_ACk_PARAMS_OUT		0x32
#define CCP_ACK_ACCESS_LOCKED	0x35
#define CCP_ACK_DAQ_NOTINIT		0x22

// ccp״̬
#define CCP_STATUS_FREE 			0
#define CCP_STATUS_CONECTING	 	1
#define CCP_STATUS_INIT_MONITOR		2
#define CCP_STATUS_REQUEST_MONITOR	3
#define CCP_STATUS_RECV_MONITOR		4
#define CCP_STATUS_REQUSET_CAL		5
#define CCP_STATUS_SET_CAL			6
#define CCP_STATUS_STORE			7
#define CCP_STATUS_CONNECT_CHECK	8
#define CCP_STATUS_DIAGNOSE			9
// ccp����״̬
#define CONNECT_STATUS_DISCONNECT	0
#define CONNECT_STATUS_CONNECTED	1
// �������״̬
#define MONITOR_STATUS_NOPREPARE 	0
#define MONITOR_STATUS_PREPARED		1

#define CCP_BUFF_LEN			1024

//#define CCP_CAL_DATA_LEN 		892
//#define CCP_MONITOR_DATA_LEN 	499
//#define ODT_NUM ((CCP_MONITOR_DATA_LEN / 7) + ((CCP_MONITOR_DATA_LEN % 7) ? 0 : -1));


typedef struct {
	
	u8 mainVersion;			// ccp���汾
	u8 releaseVersion;		// ccp�����汾
	u8 deviceIdLen;			// �豸ID����
	u8 unlockCode;			// ������

	u16 addr;
	u16 totalSize;
	u16 addrCount;
	u8 odtNum;
	u8 odtCount;

	u16 sizeCount;
	u8 dealSize;
	
	u8 data[8];
	u32 timer;
	u8 timeoutCount;
	void (*callBack)(u8 *);
		
} ccp_task_t;

typedef __packed  struct {
	u8 cmd;
	u8 ack;
	u16 addr;
	u16 len;
} ccp_head_t;

#define BLE_CCP_CMD_CONNECT 			(1 << 0)
#define BLE_CCP_CMD_MONITOR_INIT 		(1 << 1)
#define BLE_CCP_CMD_MONITOR_REQUEST 	(1 << 2)
#define BLE_CCP_CMD_CAL_REQUEST		(1 << 3)
#define BLE_CCP_CMD_CAL_SET			(1 << 4)
#define BLE_CCP_CMD_CAL_STORE			(1 << 5)

#define CCP_ACK_RIGHT		1
#define CCP_ACK_ERROR		0

extern u8 ccp_task_flag;
extern u8 ccp_buff[CCP_BUFF_LEN];
extern ccp_task_t ccp_task;
extern u32 timer_10ms;
extern u8 ccp_status;
extern u8 ccp_connect_status;
extern u8 ccp_monitor_status;
extern ccp_head_t ccp_head;

void exec_ccp_task(void);

u8 CCP_COUNT_INC(void);
u8 ccp_send_msg(u8 data[]);
void ccp_reset_timeout(u32 *timer); 
void ccp_free(void);
u8 ccp_is_free(void);

void ccp_do_connect(void (*callBack)(u8 *));
void ccp_do_short_up(u8 size, u32 addr, void (*callBack)(u8 *));

u8 ccp_is_disconnected(void);
u8 ccp_is_connected(void);
u8 ccp_is_connecting(void);

u8 ccp_is_monitor_noprepare(void);
u8 ccp_is_monitor_preparing(void);
u8 ccp_is_monitor_prepared(void);

u8 ccp_connect(void);
u8 ccp_init_monitor(void);
u8 ccp_request_monitor(void);
u8 ccp_set_cal(void);
u8 ccp_requset_all_cal(void);
u8 ccp_request_cal(void);
u8 ccp_store_cal(void);
u8 ccp_restore_cal(void);

void deal_ccp_msg(CanRxMsg *ccpMsg);

//***************************************
void ccp_deal_timeout(void);
void ccp_deal_disconnect(void);
#endif
