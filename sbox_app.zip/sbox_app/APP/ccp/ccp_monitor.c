#include <stdio.h>
#include <string.h>
#include "ccp.h"
#include "can_manager.h"
#include "delay.h"

//****************************************************************************
/*
 * �������ݳ�ʼ��
 */
#define _DEBUG_MONITOR_ 	0
extern u8 ccp_set_daq_ptr(u8 backMsg[]);
extern u8 ccp_write_daq(u8 backMsg[]);
u8 ccp_init_monitor()
{
	if(!ccp_is_free()) {
		return 0;
	}
	if(!ccp_is_connected()) {
		ccp_task_flag |= BLE_CCP_CMD_CONNECT;
		return 0;
	}
	ccp_status = CCP_STATUS_INIT_MONITOR;
	ccp_monitor_status = MONITOR_STATUS_NOPREPARE;
	ccp_task.addrCount = ccp_task.addr;
	
	memset(ccp_task.data, 0, 8);
	ccp_task.data[0] = CCP_CMD_GET_DAQ_SIZE;
	ccp_task.data[1] = CCP_COUNT_INC();
	ccp_task.data[2] = 0;

	ccp_task.callBack 	= (void (*)())ccp_set_daq_ptr;
	
	ccp_send_msg(ccp_task.data);
	LOGDln("ccp monitor init start");
	#if _DEBUG_MONITOR_
		LOGDln("ccp_get_daq_size:%d", ccp_task.data[1]);
	#endif 
	return 1;

}

u8 ccp_set_daq_ptr(u8 backMsg[])
{
	if(backMsg[0] != 0xFF) {
		return 0;
	}
	if(backMsg[1] != 0x00) {
		ccp_status = CCP_STATUS_FREE;
		ccp_connect_status = CONNECT_STATUS_DISCONNECT;
		ccp_task_flag |= BLE_CCP_CMD_MONITOR_INIT;
		return 0;
	}
	
	if(ccp_task.data[0] == CCP_CMD_WRITE_DAQ) {
		if(ccp_task.addrCount == ccp_task.totalSize) {
			ccp_monitor_status = MONITOR_STATUS_PREPARED;
			ccp_status = CCP_STATUS_FREE;	
			LOGDln("ccp monitor init success");
			return 2;
		}
	} else if(ccp_task.data[0] != CCP_CMD_GET_DAQ_SIZE) {
		return 0;
	}
	u8 count = CCP_COUNT_INC();
	
	memset(ccp_task.data, 0, 8);
	ccp_task.data[0] = CCP_CMD_SET_DAQ_PTR;
	ccp_task.data[1] = (count % 2) == 1 ? count : CCP_COUNT_INC(); // countֵ����Ϊ����
	ccp_task.data[2] = 0;
	ccp_task.data[3] = ccp_task.addrCount / 7;
	ccp_task.data[4] = ccp_task.addrCount % 7;
	
	ccp_task.callBack	= (void (*)())ccp_write_daq;

	ccp_send_msg(ccp_task.data);

	#if _DEBUG_MONITOR_
		LOGDln("ccp_set_daq_ptr:%d", ccp_task.data[1]);
	#endif 
	// LOG("ccp addr count:%d\r\n", ccp_task.addrCount);
	return 1;
	
}

u8 ccp_write_daq(u8 backMsg[])
{
	if(backMsg[0] != 0xFF) {
		return 0;
	}
	if(backMsg[1] != 0x00) {
		ccp_status = CCP_STATUS_FREE;
		ccp_connect_status = CONNECT_STATUS_DISCONNECT;
		ccp_task_flag |= BLE_CCP_CMD_MONITOR_INIT;
		return 0;
	}
	
	
	if(ccp_task.data[0] != CCP_CMD_SET_DAQ_PTR) {
		return 0;
	}
	u8 count = CCP_COUNT_INC();
	u32 addr = ccp_task.addrCount + CCP_MONITOR_BASE_ADDR;
	
	memset(ccp_task.data, 0, 8);
	ccp_task.data[0] = CCP_CMD_WRITE_DAQ;
	ccp_task.data[1] = (count % 2) == 0 ? count : CCP_COUNT_INC(); // countֵ����Ϊż��
	ccp_task.data[2] = 0x01;
	ccp_task.data[4] = (addr >> 24) & 0xFF;
	ccp_task.data[5] = (addr >> 16) & 0xFF;
	ccp_task.data[6] = (addr >> 8)  & 0xFF;
	ccp_task.data[7] = (addr >> 0)  & 0xFF;

	ccp_task.callBack = (void (*)())ccp_set_daq_ptr;
	
	ccp_task.addrCount++;
	ccp_send_msg(ccp_task.data);
	
	#if _DEBUG_MONITOR_
		LOG("ccp_write_daq:%d\r\n", ccp_task.data[1]);
	#endif 
	
	return 1;
}


//****************************************************************************
/*
 * ����������
 */
extern void ccp_start_daq_callback(u8 backMsg[]);
extern void ccp_recv_monitor(u8 backMsg[]);
extern void send_ble_monitor_msg(void);
u8 ccp_request_monitor()
{
	if(!ccp_is_free()) {
		return 0;
	}
	
	if(!ccp_is_connected()) {
		ccp_task_flag |= BLE_CCP_CMD_CONNECT;
		return 0;
	}
	if(!ccp_is_monitor_prepared()) {
		ccp_task_flag |= BLE_CCP_CMD_MONITOR_INIT;
		return 0;
	}
		
	LOGDln("start request monitor data");
	ccp_status = CCP_STATUS_REQUEST_MONITOR;
	ccp_task.odtNum = 
		((ccp_task.totalSize / 7) + ((ccp_task.totalSize % 7) ? 0 : -1));
	
	memset(ccp_task.data, 0, 8);
	ccp_task.data[0] = CCP_CMD_START_STOP_DAQ;
	ccp_task.data[1] = CCP_COUNT_INC();
	ccp_task.data[2] = 0x01; // startģʽ
	ccp_task.data[3] = 0;
	ccp_task.data[4] = ccp_task.odtNum;
	ccp_task.data[5] = 1;
	ccp_task.data[6] = 0;
	ccp_task.data[7] = 0;


	ccp_task.callBack 	= (void (*)())ccp_start_daq_callback;
	
	ccp_send_msg(ccp_task.data);

	#if _DEBUG_MONITOR_
		LOGDln("ccp_start_daq:%d", ccp_task.data[1]);
	#endif 
	
	return 1;
}

void ccp_start_daq_callback(u8 backMsg[])
{
	if(backMsg[0] == 0xFF && backMsg[1] == 0x00) {
		ccp_status = CCP_STATUS_RECV_MONITOR;
		ccp_task.odtCount = 0;
		ccp_task.callBack 	= (void (*)())ccp_recv_monitor;
		LOGDln("ccp start recv monitor datas");
	} else {
		ccp_task_flag |= BLE_CCP_CMD_MONITOR_REQUEST;
		ccp_monitor_status = MONITOR_STATUS_NOPREPARE;
		ccp_status = CCP_STATUS_FREE;
		LOGDln("ccp start recv monitor failed");
	}
}

void ccp_recv_monitor(u8 data[])
{
	u16 offset = data[0] * 7;
	u8 odtCount = ccp_task.odtCount;
	
	//LOG("ODT count:%d, num: %02x\r\n", odtCount, data[0]);
	if(odtCount < ccp_task.odtNum) {
		memcpy(&ccp_buff[offset], &data[1], 7);
		ccp_task.odtCount++;
	} else if(odtCount == ccp_task.odtNum){
		// ���һ��������
		u8 size = ccp_task.totalSize % 7;
		size = size == 0 ? 7 : size;
		
		ccp_status = CCP_STATUS_FREE;
		
		memcpy(&ccp_buff[offset], &data[1], size);
		
		LOGDln("recv monitor datas success, len:%d", odtCount * 7 + size);
		send_ble_monitor_msg();
		LOGDln("send monitor msg to ble success");
		#if _DEBUG_MONITOR_
			log_array(&ccp_buff[0], CCP_MONITOR_DATA_LEN);
		#endif
	}
}
/**
 * ��ble���ͼ������
 */
void send_ble_monitor_msg() 
{
	u16 startAddr = 0;
	u16 totalLen = ccp_task.totalSize;
	u16 sendMaxLen = BLE_MSG_MAX_SEND_LEN - sizeof(ccp_head);
	u16 sendLen;
	
	do {
		sendLen = totalLen > sendMaxLen ? sendMaxLen : totalLen;
		ccp_head.cmd = BLE_CCP_CMD_MONITOR_REQUEST;
		ccp_head.ack = CCP_ACK_RIGHT;
		ccp_head.addr = BigLittleSwap16(startAddr); //startAddr;
		ccp_head.len = BigLittleSwap16(sendLen);
		ble_send_with_head(BLE_CMD_CCP_MSG, (u8 *)&ccp_head, sizeof(ccp_head), &ccp_buff[startAddr], sendLen);
		LOGDln("send %d bytes of monitor msg to ble", sendLen);
		totalLen -= sendLen;
		startAddr += sendLen;
		delay_ms(2);
	} while(totalLen > 0);
	
}


