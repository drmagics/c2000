#include <stdio.h>
#include <string.h>
#include "ccp.h"
#include "can_manager.h"
#include "delay.h"

/*
 * ����ccp����
 */
#define _DEBUG_CONNECT_ 	1
extern u8 ccp_get_version(void);
extern u8 ccp_get_exchange_id(void);
extern u8 ccp_get_seed(void);
extern u8 ccp_unlock(void);

extern void ccp_connect_callBack(u8 backMsg[]);
extern void ccp_get_version_callBack(u8 backMsg[]);
extern void ccp_get_exchange_id_callBack(u8 backMsg[]);
extern void ccp_get_seed_callBack(u8 backMsg[]);
extern void ccp_unlock_callBack(u8 backMsg[]);


/*
 * ��ʼccp����
 */

u8 ccp_connect()
{
	if(!ccp_is_free() && ccp_connect_status != CONNECT_STATUS_DISCONNECT) {
		return 0;
	}
	ccp_status = CCP_STATUS_CONECTING;
	
	memset(ccp_task.data, 0, 8);
	ccp_task.data[0] = CCP_CMD_CONNECT;
	ccp_task.data[1] = CCP_COUNT_INC();
	ccp_task.data[2] = (CCP_STATION_ADDRESS >> 8) & 0xFF;
	ccp_task.data[3] = (CCP_STATION_ADDRESS >> 0) & 0xFF;
	
	ccp_task.callBack = ccp_connect_callBack;
	
	ccp_send_msg(ccp_task.data);
	#if _DEBUG_CONNECT_
		LOG("ccp_command_connect:%d\r\n", ccp_task.data[1]);
	#endif 
	return 1;
}

void ccp_connect_callBack(u8 backMsg[])
{
	ccp_get_version();
}

/*
 * ccp_get_version
 */
u8 ccp_get_version()
{
	memset(ccp_task.data, 0, 8);
	ccp_task.data[0] = CCP_CMD_GET_VERSION;
	ccp_task.data[1] = CCP_COUNT_INC();
	ccp_task.data[2] = 0x02;
	ccp_task.data[3] = 0x01;
	
	ccp_task.callBack 	= ccp_get_version_callBack;
	
	ccp_send_msg(ccp_task.data);
	#if _DEBUG_CONNECT_
		LOG("ccp_command_get_version:%d\r\n", ccp_task.data[1]);
	#endif 
	return 1;
}
void ccp_get_version_callBack(u8 backMsg[])
{
	ccp_task.mainVersion 	= backMsg[2];
	ccp_task.releaseVersion = backMsg[3];
	ccp_get_exchange_id();
}


/*
 * ccp_get_exchange_id
 */
u8 ccp_get_exchange_id()
{
	memset(ccp_task.data, 0, 8);
	ccp_task.data[0] = CCP_CMD_EXCHANGE_ID;
	ccp_task.data[1] = CCP_COUNT_INC();

	ccp_task.callBack 	= ccp_get_exchange_id_callBack;
	
	ccp_send_msg(ccp_task.data);
	#if _DEBUG_CONNECT_
		LOG("ccp_command_get_exchange_id:%d\r\n", ccp_task.data[1]);
	#endif 
	return 1;
}

void ccp_get_exchange_id_callBack(u8 backMsg[]) 
{
	ccp_task.unlockCode = 0;
	ccp_get_seed();
}

/*
 * ccp_get_seed
 */
u8 ccp_get_seed()
{	
	memset(ccp_task.data, 0, 8);
	ccp_task.data[0] = CCP_CMD_GET_SEED;
	ccp_task.data[1] = CCP_COUNT_INC();
	u8 unlockCode = ccp_task.unlockCode;
	if(!GET_1BIT(unlockCode, 0)) {
		ccp_task.data[2] = 0x01;
	} else if(!GET_1BIT(unlockCode, 1)) {
		ccp_task.data[2] = 0x02;
	} else if(!GET_1BIT(unlockCode, 2)) {
		ccp_task.data[2] = 0x04;
	} else if(!GET_1BIT(unlockCode, 6)) {
		ccp_task.data[2] = 0x40;
	} else {
		ccp_status = CCP_STATUS_FREE;
		ccp_connect_status = CONNECT_STATUS_CONNECTED;
		LOG("ccp connect success :0x%02x\r\n", unlockCode);
		return 2;
	}

	ccp_task.callBack = ccp_get_seed_callBack;
	
	ccp_send_msg(ccp_task.data);

	#if _DEBUG_CONNECT_
		LOG("ccp_command_get_seed:%d, %d, 0x%02x\r\n", ccp_task.data[1], 
			ccp_task.data[2], unlockCode);
	#endif 
	return 1;
}

void ccp_get_seed_callBack(u8 backMsg[])
{
	ccp_unlock();
}

/*
 * ccp_unlock
 */
u8 ccp_unlock()
{
	memset(ccp_task.data, 0, 8);
	ccp_task.data[0] = CCP_CMD_UNLOCK;
	ccp_task.data[1] = CCP_COUNT_INC();
	ccp_task.data[2] = (CCP_KEY >> 24) & 0xFF;
	ccp_task.data[3] = (CCP_KEY >> 16) & 0xFF;
	ccp_task.data[4] = (CCP_KEY >> 8)  & 0xFF;
	ccp_task.data[5] = (CCP_KEY >> 0)  & 0xFF;

	ccp_task.callBack 	= ccp_unlock_callBack;
	
	ccp_send_msg(ccp_task.data);
	#if _DEBUG_CONNECT_
		LOG("ccp_command_unlock:%d\r\n", ccp_task.data[1]);
	#endif 
	return 1;
}

void ccp_unlock_callBack(u8 backMsg[])
{
	ccp_task.unlockCode = backMsg[3];
	ccp_get_seed();
}







