#include "uds_manager.h"
#include "can_manager.h"
#include "UDS.h"
#include "ISOTP.h"
#include "bt_manager.h"


void uds_connect_init(void) {
            order = 0 ;
	     if(order == 0) {
		     modify_session_flag = 0 ;
		     secure_session_flag = 0 ;
		     verify_session_flag = 0 ;
		     modify_funsession_flag = 0 ;
			 comm_funsession_flag = 0;
			 modify_session_flag1 = 0 ;
			 buff_read_flag = 0;
		     UDS_Receive_Status =0 ;
		     UDS_Verify_Status  =0 ;
		     UDS_SafeRequest_Status =0 ;
	         uds_task_flag =0;
			 uds_connect_status = UDS_STATUS_DISCONNECT;
		     LOGEln("UDS  INIT  \r\n");
		 }    	
	        order = 1;
     }
	
void  MSG_DealUds(TYPE_Can *canMsg) {
			
//		LOGEln("Recv Can Msg:%08x,%02x,%02x,%02x,%02x,%02x,%02x,%02x,%02x\r\n",
//				canMsg->id, 
//				canMsg->data[0], canMsg->data[1], 
//				canMsg->data[2], canMsg->data[3], 
//				canMsg->data[4], canMsg->data[5],
//				canMsg->data[6], canMsg->data[7]);	
			
	u32 DataCt[2];
	u32 CanID=0;
	u8  len;
	CanID = canMsg->id;
	len = (uint8_t)canMsg->dlc;

	memcpy(DataCt,canMsg->data,sizeof(canMsg->data));
		  
	//DataCt[0] = (Udsdata[3] << 24) + (Udsdata[2] << 16) + (Udsdata[1] << 8) + (Udsdata[0]);
	//DataCt[1] = (Udsdata[7] << 24) + (Udsdata[6] << 16) + (Udsdata[5] << 8) + (Udsdata[4]);
	//CAN_LOG("CanID: %08x,%02x,%02x,%02x,%02x,%02x,%02x,%02x,%02x \r\n", CanID,
	//Udsdata[0],Udsdata[1] ,Udsdata[2] ,Udsdata[3] ,
	//Udsdata[4],Udsdata[5] ,Udsdata[6] ,Udsdata[7]);
	//CAN_LOG("CanID: %08x, %08x ,%08x\r\n", CanID, DataCt[0] ,DataCt[1]);
	if(	(CanID ==0xf5 ) || (CanID ==0xf8))
	{
	    LOGEln("CanUpg_RecvData \r\n");
		CanUpg_RecvData(CanID,DataCt,len);
	}	
	else
	{
	   DLIndication(CanID,DataCt,len);
	}
}

uint8_t   order = 0;
uint8_t   SL_DTC = 0;
extern u32 g_SysTicks;
extern u8 g_BtCanSendFlag;

void UDS_WriteVin(char *vin)
{
	memcpy(SEND_VIN, vin, 17);
	uds_task_flag |=  BLE_UDS_CMD_WRITE_VIN ;
	uds_connect_init();
	write_success_flag = 0;
}	

void onClearSetTroubleCallback()
{
 uds_trouble_t trouble;
 trouble.cmd = TROUBLE_SET_CLEAR;
 trouble.ack = 1;
 BT_SendMsg(BT_ACK_TROUBLE, &trouble, 2);
	//g_BtCanSendFlag = 1;
}

void onClearHistoryTroubleCallback()
{
 uds_trouble_t trouble;
 trouble.cmd = TROUBLE_HISTORY_CLEAR;
 trouble.ack = 1;
 BT_SendMsg(BT_ACK_TROUBLE, &trouble, 2);
	//g_BtCanSendFlag = 1;
}

void onRequestHistoryTroubleCodeCallback(u8 codes[], u8 len)
{
 uds_trouble_t trouble;
 trouble.cmd = TROUBLE_HISTORY;
 trouble.ack = 1;
 BT_SendMsgWithHead(BT_ACK_TROUBLE, &trouble, 2, codes, len);
// g_BtCanSendFlag = 1;
}
//s32  uds_TimeEnableCan(TimeTask_t *timeTask)
//{
//	timeTask->isUsed = FALSE;
//	g_BtCanSendFlag = 1;
//	return 0;
//}
void UDS_Trouble(u8 *data, u8 size)
{
	uds_trouble_t *pTrouble = (uds_trouble_t *)data;
	
	switch(pTrouble->cmd) {
		case TROUBLE_SET:
			uds_connect_init();
		    send_success_flag = 0;
		    pTrouble->code = BigLittleSwap32(pTrouble->code);
			SL_DTC = pTrouble->code;
		    uds_task_flag |=  BLE_UDS_CMD_SEND_SL_DTC ;
		    LOGDln("trouble set:%d", pTrouble->code);
			break;
		
		case TROUBLE_SET_CLEAR:
			uds_connect_init();
		    clear_success_flag= 0 ;
		    uds_task_flag |=  BLE_UDS_CMD_DEL_SL_DTC ;
		    LOGDln("trouble clear");
			break;
		
		case TROUBLE_HISTORY:
			uds_connect_init();
		    read_DTC_success_flag = 0 ;
		    uds_task_flag |=  BLE_UDS_CMD_READ_DTC ;
		    LOGDln("trouble history");
		   
			break;
		
		case TROUBLE_HISTORY_CLEAR:
			uds_connect_init();
		    clear_DTC_success_flag = 0 ;
		    uds_task_flag |= BLE_UDS_CMD_DEL_DTC ;
		    LOGDln("trouble history clear");
			break;
		
		default :
			break;
	}
}
