#ifndef __UDS_MANAGER_H__
#define __UDS_MANAGER_H__


#include "common.h"

enum {

	TROUBLE_SET = 1,
	TROUBLE_SET_CLEAR = 2,
	TROUBLE_HISTORY = 3,
	TROUBLE_HISTORY_CLEAR = 4,
};
#pragma pack (1) // ָ����һ�ֽڶ���
typedef struct {

	u8 cmd;
	u8 ack;
	u32 code;
	
} uds_trouble_t;


#pragma pack () // ȡ��ָ���ṹ�����


void UDS_WriteVin(char *vin);
void UDS_Trouble(u8 *data, u8 size);
void uds_connect_init(void);
extern void onClearSetTroubleCallback(void);
extern void onClearHistoryTroubleCallback(void);
extern void onRequestHistoryTroubleCodeCallback(u8 codes[], u8 len);
extern uint8_t write_success_flag;
extern uint8_t modify_session_flag;
extern uint8_t secure_session_flag;
extern uint8_t verify_session_flag;
extern uint8_t Write_Vin_flag;
extern uint8_t Read_Vin_flag;
extern uint8_t read_success_flag;
extern uint8_t buff_read_flag;
extern uint8_t UDS_Receive_Status;
extern uint8_t UDS_Verify_Status;
extern uint8_t UDS_SafeRequest_Status;
extern uint8_t SEND_VIN[17];
extern uint8_t READ_VIN[17];
extern uint8_t SL_DTC ;
extern uint8_t order ;
extern uint8_t modify_funsession_flag;
extern uint8_t comm_funsession_flag ;
extern uint8_t modify_session_flag1;
extern uint8_t request_download_flag;
extern uint8_t uds_upgrade_success_flag ;



#endif
