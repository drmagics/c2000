#ifndef __ADC_H__
#define __ADC_H__

#include "common.h"

#define ADC_MAX_VALUE		4096

#define PWR_BAT_ADC_PORT		GPIOC
#define PWR_BAT_ADC_PIN			GPIO_Pin_4
#define PWR_BAT_ADC_CH			ADC_Channel_14
#define PWR_BAT_ADC_SCALE		1

#define PWR_5V_ADC_PORT			GPIOC
#define PWR_5V_ADC_PIN			GPIO_Pin_5
#define PWR_5V_ADC_CH			ADC_Channel_15
#define PWR_5V_ADC_SCALE		1


#define PWR_4V_ADC_PORT			GPIOB
#define PWR_4V_ADC_PIN			GPIO_Pin_0
#define PWR_4V_ADC_CH			ADC_Channel_8
#define PWR_4V_ADC_SCALE		1


#define PWR_12V_ADC_PORT		GPIOB
#define PWR_12V_ADC_PIN			GPIO_Pin_1
#define PWR_12V_ADC_CH			ADC_Channel_9
#define PWR_12V_ADC_SCALE		1



#define ADC_CHANNEL_NUM			4
#define ADC_BUFF_SIZE			30
#define ADC_BASE_VOL			3.3f

void ADC_Start(void);
float ADC_GetVol_BAT(void);
float ADC_GetVol_5V(void);
float ADC_GetVol_12V(void);
float ADC_GetVol_4V(void);








#endif
