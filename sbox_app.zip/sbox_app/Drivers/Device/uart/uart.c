#include <stdarg.h>	 	 	 	 
#include <string.h>	
#include <stdio.h>
#include "uart.h"


//////////////////////////////////////////////////////////////////
//�������´���,֧��printf����,������Ҫѡ��use MicroLIB	  
#if 1
#pragma import(__use_no_semihosting)             
//��׼����Ҫ��֧�ֺ���                 
struct __FILE 
{ 
	int handle; 

}; 

FILE __stdout;       
//����_sys_exit()�Ա���ʹ�ð�����ģʽ    
void _sys_exit(int x) 
{ 
	x = x; 
} 
//�ض���fputc���� 

#define USART_DEBUG				USART2
int fputc(int ch, FILE *f)
{      
	while(USART_GetFlagStatus(USART_DEBUG, USART_FLAG_TC) == RESET) {}
    USART_SendData(USART_DEBUG, (unsigned char)ch);
	return ch;
}
#endif 


UART_TypeDef UART_TypeDefs[] = {
{
	.USARTx 	= USART1,
	.baud 		= 115200 * 4,
	.gpio = 
	{
		.GPIOx = GPIOA,
		.tx_pin		= GPIO_Pin_9,
		.rx_pin		= GPIO_Pin_10,
	},
	
	.irq =
	{
		.priority	= 0,
		.IRQn		= USART1_IRQn,
	},

	.dma = {
		.tx_CHx		= DMA1_Channel4,
		.rx_CHx		= DMA1_Channel5,
		.irq_tx = DMA1_Channel4_IRQn,    
		.irq_rx = DMA1_Channel5_IRQn,  
		.TX_IT_FLAG_TCx = DMA1_IT_TC4,
		.RX_IT_FLAG_TCx = DMA1_IT_TC5,
	},

	.buff = {
		.rx_head = 0,
		.rx_tail = 0,
		.rx_buf_size = 0,
	},
},

{
	.USARTx 	= USART2,
	.baud 		= 115200,
	.gpio = 
	{
		.GPIOx = GPIOA,
		.tx_pin		= GPIO_Pin_2,
		.rx_pin		= GPIO_Pin_3,
	},
	
	.irq =
	{
		.priority	= 1,
		.IRQn		= USART2_IRQn,
	},

	.dma = {
		.tx_CHx		= DMA1_Channel7,
		.rx_CHx		= DMA1_Channel6,
		.irq_tx = DMA1_Channel7_IRQn,    
		.irq_rx = DMA1_Channel6_IRQn, 
		.TX_IT_FLAG_TCx = DMA1_IT_TC7,
		.RX_IT_FLAG_TCx = DMA1_IT_TC6,
	},

	.buff = {
		.rx_head = 0,
		.rx_tail = 0,
		.rx_buf_size = 0,
	},
},

{
	.USARTx 	= USART3,
	.baud 		= 115200,
	.gpio = 
	{
		.GPIOx		= GPIOB,
		.tx_pin		= GPIO_Pin_10,
		.rx_pin		= GPIO_Pin_11,
	},
	
	.irq =
	{
		.priority	= 2,
		.IRQn		= USART3_IRQn,
	},

	.dma = {
		.tx_CHx		= DMA1_Channel2,
		.rx_CHx		= DMA1_Channel3,
		.irq_tx = DMA1_Channel2_IRQn,    
		.irq_rx = DMA1_Channel3_IRQn, 
		.TX_IT_FLAG_TCx = DMA1_IT_TC2,
		.RX_IT_FLAG_TCx = DMA1_IT_TC3,
	},

	.buff = {
		.rx_head = 0,
		.rx_tail = 0,
		.rx_buf_size = 0,
	},
},

};

/***************** GPIO ���� ************************/
void UART_GPIO_Config(UART_TypeDef *p)
{
	//GPIO�˿�����
	GPIO_InitTypeDef GPIO_InitStructure;
	
	if(p->USARTx == USART1) {
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1 | RCC_APB2Periph_GPIOA, ENABLE);	
	} else if(p->USARTx == USART2) {
		RCC_APB2PeriphClockCmd(RCC_APB1Periph_USART2 | RCC_APB2Periph_GPIOA, ENABLE);	
	} else if(p->USARTx == USART3) {
		RCC_APB2PeriphClockCmd(RCC_APB1Periph_USART3 | RCC_APB2Periph_GPIOB, ENABLE);	
	}
	//USARTx_TX 
	GPIO_InitStructure.GPIO_Pin = p->gpio.tx_pin;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;	//�����������
	GPIO_Init(p->gpio.GPIOx, &GPIO_InitStructure);

	//USARTx_RX
	GPIO_InitStructure.GPIO_Pin = p->gpio.rx_pin;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING; //��������
	GPIO_Init(p->gpio.GPIOx, &GPIO_InitStructure);//��ʼ��GPIOA.10  
}



/***************** ���������� ************************/
void UART_Baud_Config(UART_TypeDef *p)
{
	USART_InitTypeDef USART_InitStructure;
	
	USART_InitStructure.USART_BaudRate = p->baud;//����������
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;//8λ���ݳ���
	USART_InitStructure.USART_StopBits = USART_StopBits_1;//һ��ֹͣλ
	USART_InitStructure.USART_Parity = USART_Parity_No;///��żУ��λ
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;//��Ӳ������������
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;//�շ�ģʽ

	USART_Init(p->USARTx, &USART_InitStructure); ; //��ʼ������
}



/***************** �ж����� ************************/
void UART_IRQ_Config(UART_TypeDef *p)
{
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = p->irq.IRQn;	 
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = p->irq.priority;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

	USART_ITConfig(p->USARTx, USART_IT_IDLE, ENABLE);//ʹ�ܴ��ڽ����ж� 
}

/***************** buff���� ************************/
void UART_Buff_Config(UART_TypeDef *p, u8 *rxBuf, u16 rxLen, u8 *txBuf, u16 txLen)
{
	UART_Buff_t *pBuff = &p->buff;
	pBuff->rx_buf = rxBuf;
	pBuff->rx_buf_max = rxLen;
	pBuff->rx_buf_size = 0;
	pBuff->rx_head = 0;
	pBuff->rx_tail = 0;
	
	pBuff->tx_buf = txBuf;
	pBuff->tx_buf_max = txLen;
}

/***************** DMA �������� ************************/
void UART_DMA_RX_Config(UART_TypeDef *p)
{
	DMA_InitTypeDef		DMA_InitStructure;
	NVIC_InitTypeDef 	NVIC_InitStructure;
	
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);
			
	USART_DMACmd(p->USARTx, USART_DMAReq_Rx, ENABLE);// ʹ��DMA���ڽ�������
	//DMA RX Config
	DMA_DeInit(p->dma.rx_CHx);
	DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)(&p->USARTx->DR);	// �������ַ
	DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t)p->buff.rx_buf;		// �ڴ����ַ
	DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC;						// ���ݴ��䷽���ڴ浽����ģʽ
	DMA_InitStructure.DMA_BufferSize = p->buff.rx_buf_max;					// DMAͨ����DMA����Ĵ�С
	DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;	   	// �����ַ���ֲ���
	DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;					// �洢����ַ����
	DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;	// ��������λ��:8λ
	DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;			// �洢������λ��:8λ
	DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;							// ����������ģʽ
	DMA_InitStructure.DMA_Priority = DMA_Priority_VeryHigh;					// �е����ȼ�
	DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;							// DMAͨ��xû������Ϊ�ڴ浽�ڴ洫��
	DMA_Init(p->dma.rx_CHx, &DMA_InitStructure);
	DMA_Cmd(p->dma.rx_CHx, ENABLE);
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    NVIC_InitStructure.NVIC_IRQChannel = p->dma.irq_rx;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
    DMA_ITConfig(p->dma.rx_CHx, DMA_IT_TC, ENABLE);

}

/***************** DMA �������� ************************/
void UART_DMA_TX_Config(UART_TypeDef *p)
{
	DMA_InitTypeDef   DMA_InitStructure;
	NVIC_InitTypeDef 	NVIC_InitStructure;
	
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);

	USART_DMACmd(p->USARTx, USART_DMAReq_Tx, ENABLE);// ʹ��DMA���ڷ�������
    //DMA TX Config
    DMA_DeInit(p->dma.tx_CHx);
    DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)(&p->USARTx->DR);
    DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t)p->buff.tx_buf;
    DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralDST;
    DMA_InitStructure.DMA_BufferSize = p->buff.tx_buf_max;
    DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
    DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
    DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
    DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
    DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
    DMA_InitStructure.DMA_Priority = DMA_Priority_VeryHigh;
    DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
    DMA_Init(p->dma.tx_CHx, &DMA_InitStructure);
		
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    NVIC_InitStructure.NVIC_IRQChannel = p->dma.irq_tx;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
	DMA_ITConfig(p->dma.tx_CHx, DMA_IT_TC, ENABLE);
	
	DMA_Cmd(p->dma.tx_CHx, DISABLE);
	DMA_ClearITPendingBit(p->dma.TX_IT_FLAG_TCx);

}


/**
 *	���ڷ���
 */
void UART_DMASend(UART_TypeDef *p, u8 *buf, u16 length)  
{  
	memcpy(p->buff.tx_buf, buf, length);
	
	while(DMA_GetFlagStatus(p->dma.TX_IT_FLAG_TCx) == SET){} //�ȴ�ͨ���������
    DMA_SetCurrDataCounter(p->dma.tx_CHx, length);	// ���÷��ͳ���
    DMA_Cmd(p->dma.tx_CHx, ENABLE);					// ����DMA����

}

void UART_Send(UART_TypeDef *p, u8 *buf, u16 length) 
{
	u16 i;
	for (i = 0; i < length; i++)//ѭ����������
	{
		USART_SendData(p->USARTx, (uint8_t) buf[i]);
		while (USART_GetFlagStatus(p->USARTx, USART_FLAG_TXE) == RESET);
	} 
}

/**
 * ���ڽ�������
 */
void UART_PutData(UART_TypeDef *p)
{
	UART_Buff_t *pBuff = &p->buff;
	
	u16 tail = pBuff->rx_buf_max - DMA_GetCurrDataCounter(p->dma.rx_CHx);
	u16 len;
	LOGDln("tail:%d", tail);
	if(tail > pBuff->rx_tail) {
		len = tail - pBuff->rx_tail;
	} else if(tail < pBuff->rx_tail) {
		len = pBuff->rx_buf_max - pBuff->rx_tail;
		len += tail;
	} else {
		return;
	}
	pBuff->rx_tail = tail;
	pBuff->rx_buf_size += len;
	if(pBuff->rx_buf_size > pBuff->rx_buf_max) {
		pBuff->rx_buf_size = pBuff->rx_buf_max;
		pBuff->rx_head = pBuff->rx_tail;
	}
}


u16 UART_GetData(UART_TypeDef *p, u8 *data, u16 *len)
{
	UART_Buff_t *pBuff = &p->buff;
	if(pBuff == NULL || data == NULL || pBuff->rx_buf_size == 0) {
		return 0;
	}
	
	u16 head = pBuff->rx_head;
	u16 tail = pBuff->rx_tail;
	u16 size = 0;
	
	if(head < tail) {
		size = tail - head;
		memcpy(data, &pBuff->rx_buf[head], size);
		pBuff->rx_head = pBuff->rx_tail;
		pBuff->rx_buf_size = 0;
	} else {
		size = pBuff->rx_buf_max - head;
		memcpy(data, &pBuff->rx_buf[head], size);
		memcpy(data + size, &pBuff->rx_buf[0], tail);
		
		size += tail;
		pBuff->rx_head = pBuff->rx_tail;
		pBuff->rx_buf_size = 0;
	}
	
	if(len != NULL) {
		*len = size;
	} 
	return size;
}
/**
 * ����1�жϷ������
 */
void USART1_IRQHandler(void)                	
{
	if(USART_GetITStatus(USART1, USART_IT_IDLE) != RESET) {
		USART_ReceiveData(USART1); //��ȡ���յ�������	
		USART_ClearITPendingBit(USART1, USART_IT_IDLE);         //����жϱ�־
		
		UART_TypeDef *p = &UART_TypeDefs[0];
		UART_PutData(p);
    } 
}


/**
 * ����2�жϷ������
 */
void USART2_IRQHandler(void)                	
{
	if(USART_GetITStatus(USART2, USART_IT_IDLE) != RESET) {
		USART_ReceiveData(USART2); //��ȡ���յ�������	
		USART_ClearITPendingBit(USART2, USART_IT_IDLE);         //����жϱ�־
			
		UART_TypeDef *p = &UART_TypeDefs[1];
		UART_PutData(p);
    } 
}


/**
 * ����3�жϷ������
 */
void USART3_IRQHandler(void)                	
{
	if(USART_GetITStatus(USART3, USART_IT_IDLE) != RESET) {
		USART_ReceiveData(USART3); //��ȡ���յ�������	
		USART_ClearITPendingBit(USART3, USART_IT_IDLE);         //����жϱ�־
		
		UART_TypeDef *p = &UART_TypeDefs[2];
		UART_PutData(p);
    } 
}

void uart_tx_irq(UART_TypeDef *p){    

	if(DMA_GetITStatus(p->dma.TX_IT_FLAG_TCx) == SET){
		DMA_Cmd(p->dma.tx_CHx, DISABLE);
		DMA_ClearITPendingBit(p->dma.TX_IT_FLAG_TCx);
	}
}

void uart_rx_irq(UART_TypeDef *p){
    if(DMA_GetITStatus(p->dma.RX_IT_FLAG_TCx) == SET){        
        DMA_ClearITPendingBit(p->dma.RX_IT_FLAG_TCx);
    }
}

void DMA1_Channel4_IRQHandler(void)
{
//	LOGDln("DMA1_Channel4_IRQHandler");
	uart_tx_irq(&UART_TypeDefs[0]);
}

void DMA1_Channel5_IRQHandler(void)
{
//	LOGDln("DMA1_Channel5_IRQHandler");
	uart_rx_irq(&UART_TypeDefs[0]);
}

void DMA1_Channel7_IRQHandler(void)
{
	uart_tx_irq(&UART_TypeDefs[1]);
}

void DMA1_Channel6_IRQHandler(void)
{
	uart_rx_irq(&UART_TypeDefs[1]);
}

void DMA1_Channel2_IRQHandler(void)
{
	uart_tx_irq(&UART_TypeDefs[2]);
}

void DMA1_Channel3_IRQHandler(void)
{
	uart_rx_irq(&UART_TypeDefs[2]);
}


