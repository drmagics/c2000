#ifndef __CHENJUN_UART_H__
#define __CHENJUN_UART_H__
#include "common.h"


typedef struct {
	GPIO_TypeDef* GPIOx;	// GPIO �˿�
	u16 tx_pin;				// TXD pin�ź�
	u16 rx_pin;				// RXD pin�ź�
} UART_GPIO_t;

typedef struct {
	u8 priority;	// �ж����ȼ�
	u8 IRQn;			// �жϺ�
} UART_IRQ_t;

typedef struct {
	DMA_Channel_TypeDef* tx_CHx;	// ����ͨ��
	DMA_Channel_TypeDef* rx_CHx;	// ����ͨ��
	
	u8 			irq_tx;				// ����ͨ���жϺ� 
	u8 			irq_rx;				// ����ͨ���жϺ� 
	
	u32 		TX_IT_FLAG_TCx;		// ��������жϱ�־
	u32 		RX_IT_FLAG_TCx;		// ��������жϱ�־
} UART_DMA_t;

typedef struct {
	u16 rx_head;
	u16 rx_tail;
	
	u8  *rx_buf;
	u8  *tx_buf;
	
	u16 rx_buf_max;
	u16 tx_buf_max;
	u16 rx_buf_size;
} UART_Buff_t;

typedef struct UART_TypeDef_t UART_TypeDef;

struct UART_TypeDef_t{
	USART_TypeDef* USARTx;	// ���ں�
	u32 baud;				// ������

	UART_GPIO_t gpio;
	UART_IRQ_t irq;
	UART_DMA_t dma;
	
	UART_Buff_t buff;
} ;

extern UART_TypeDef UART_TypeDefs[];


void UART_GPIO_Config(UART_TypeDef *p);
void UART_Baud_Config(UART_TypeDef *p);
void UART_IRQ_Config(UART_TypeDef *p);
void UART_Buff_Config(UART_TypeDef *p, u8 *rxBuf, u16 rxLen, u8 *txBuf, u16 txLen);
void UART_DMA_RX_Config(UART_TypeDef *p);
void UART_DMA_TX_Config(UART_TypeDef *p);

void UART_DMASend(UART_TypeDef *p, u8 *buf, u16 length);
void UART_Send(UART_TypeDef *p, u8 *buf, u16 length);
u16 UART_GetData(UART_TypeDef *p, u8 *data, u16 *len);

#endif
