#include "can.h" 
#include "stm32f10x.h"

//tsjw:����ͬ����Ծʱ�䵥Ԫ.��Χ:CAN_SJW_1tq~ CAN_SJW_4tq
//tbs2:ʱ���2��ʱ�䵥Ԫ.   ��Χ:CAN_BS2_1tq~CAN_BS2_8tq;
//tbs1:ʱ���1��ʱ�䵥Ԫ.   ��Χ:CAN_BS1_1tq ~CAN_BS1_16tq
//brp :�����ʷ�Ƶ��.��Χ:1~1024;  tq=(brp)*tpclk1
//������=Fpclk1/((tbs1+1+tbs2+1+1)*brp);
//mode:CAN_Mode_Normal,��ͨģʽ;CAN_Mode_LoopBack,�ػ�ģʽ;
//Fpclk1��ʱ���ڳ�ʼ����ʱ������Ϊ36M,�������CAN_Mode_Init(CAN_SJW_1tq,CAN_BS2_8tq,CAN_BS1_9tq,4,CAN_Mode_LoopBack);
//������Ϊ:36M/((8+9+1)*4)=500Kbps
void CAN_bound(CAN_TypeDef * CANx, u8 brp)
{
	CAN_InitTypeDef        CAN_InitStructure;
	
	//���ò�����		
	CAN_InitStructure.CAN_TTCM=DISABLE;			//��ʱ�䴥��ͨ��ģʽ  
	CAN_InitStructure.CAN_ABOM=DISABLE;			//�����Զ����߹���	 
	CAN_InitStructure.CAN_AWUM=DISABLE;			//˯��ģʽͨ����������(���CAN->MCR��SLEEPλ)
	CAN_InitStructure.CAN_NART=DISABLE;			//��ֹ�����Զ����� 
	CAN_InitStructure.CAN_RFLM=DISABLE;		 	//���Ĳ�����,�µĸ��Ǿɵ�  
	CAN_InitStructure.CAN_TXFP=DISABLE;			//���ȼ��ɱ��ı�ʶ������ 

    CAN_InitStructure.CAN_Mode = CAN_Mode_Normal;  //��������ģʽ
	CAN_InitStructure.CAN_SJW=CAN_SJW_1tq;		//����ͬ����Ծ����(Tsjw)Ϊtsjw+1��ʱ�䵥λ  CAN_SJW_1tq	 CAN_SJW_2tq CAN_SJW_3tq CAN_SJW_4tq
	CAN_InitStructure.CAN_BS1=CAN_BS1_9tq; 		//Tbs1=tbs1+1��ʱ�䵥λCAN_BS1_1tq ~CAN_BS1_16tq
	CAN_InitStructure.CAN_BS2=CAN_BS2_8tq;		//Tbs2=tbs2+1��ʱ�䵥λCAN_BS2_1tq ~	CAN_BS2_8tq
	CAN_InitStructure.CAN_Prescaler=brp;        //��Ƶϵ��(Fdiv)Ϊbrp+1
	CAN_Init(CANx, &CAN_InitStructure);	
}

//---------------------------------------------------------------------------------
void CAN_SetAllfilter(u16 can_fifo, u8 Number)	//�޹���ID
{
	CAN_FilterInitTypeDef  	CAN_FilterInitStructure;
	
	CAN_FilterInitStructure.CAN_FilterNumber = Number;	//������
	CAN_FilterInitStructure.CAN_FilterMode = CAN_FilterMode_IdMask; 	//����λģʽ
	CAN_FilterInitStructure.CAN_FilterScale = CAN_FilterScale_32bit;; 	//32λ�� 
	CAN_FilterInitStructure.CAN_FilterIdHigh = 0x0000;	//32λID
	CAN_FilterInitStructure.CAN_FilterIdLow = 0x0000;
	CAN_FilterInitStructure.CAN_FilterMaskIdHigh = 0x0000;//32λMASK
	CAN_FilterInitStructure.CAN_FilterMaskIdLow = 0x0000;
	CAN_FilterInitStructure.CAN_FilterFIFOAssignment = can_fifo;//������0������FIFO0
	CAN_FilterInitStructure.CAN_FilterActivation = ENABLE;//���������0
	
	CAN_FilterInit(&CAN_FilterInitStructure);			//�˲�����ʼ��
}
//------------- ----------------------------------------------------------------
//---------------------------------------------------------------------------------
//*           CAN_Config32BitIdMaskFilter()
//*
//* ����   �� ����CAN�˲���������ģʽ�������32λ��չ֡ID
//*
//* ����   �� ids ��Ҫ����32λΪ��չ֡ID����
//*			  len : id���鳤��
//*
//* ����ֵ �� ��
//*
//* ע��   �� ��
//---------------------------------------------------------------------------------
void CAN_Config32BitIdMaskFilter(CAN_TypeDef * CANx, u8 Number, u32 ids[], u8 len)
{
	u32 tmp, mask;
    CAN_FilterInitTypeDef  CAN_FilterInitStructure;
    
    CAN_FilterInitStructure.CAN_FilterNumber = Number;
    CAN_FilterInitStructure.CAN_FilterMode = CAN_FilterMode_IdMask;
    CAN_FilterInitStructure.CAN_FilterScale = CAN_FilterScale_32bit;
    CAN_FilterInitStructure.CAN_FilterIdHigh = ((ids[0] << 3) >> 16) & 0xffff;
    CAN_FilterInitStructure.CAN_FilterIdLow =((ids[0] << 3) & 0xffff) | CAN_ID_EXT;  
	
	mask = 0x1fffffff;  

	for(u8 i = 0; i < len; i++)           
	{  
	tmp = ids[i] ^ (~ids[0]); 
	mask &=tmp;  
	}  
	mask <<=3;                        
    CAN_FilterInitStructure.CAN_FilterMaskIdHigh = (mask >> 16) & 0xffff;  
    CAN_FilterInitStructure.CAN_FilterMaskIdLow = (mask & 0xffff) | 0x02;  
    CAN_FilterInitStructure.CAN_FilterFIFOAssignment = CAN_FIFO0;
    CAN_FilterInitStructure.CAN_FilterActivation = ENABLE;
 
    CAN_FilterInit(&CAN_FilterInitStructure);
	
	CAN_ITConfig(CANx, CAN_IT_FMP0, ENABLE);
}

u8 CAN_SetFilterStdIds(u8 can_fifo, u8 fifoNum, u16 ids[], u8 len)
{
	CAN_FilterInitTypeDef  CAN_FilterInitStructure;
	u8 i = 0;
	while(fifoNum < CAN_MAX_FILTER && i < len) {
		CAN_FilterInitStructure.CAN_FilterNumber = fifoNum++;
		CAN_FilterInitStructure.CAN_FilterMode = CAN_FilterMode_IdList;
		CAN_FilterInitStructure.CAN_FilterScale = CAN_FilterScale_16bit;
		
		CAN_FilterInitStructure.CAN_FilterIdHigh = (ids[i] << 5) | CAN_ID_STD | CAN_RTR_DATA;
		i++;
		if(i < len) {
			CAN_FilterInitStructure.CAN_FilterIdLow = (ids[i] << 5) | CAN_ID_STD | CAN_RTR_DATA;
		} else {
			CAN_FilterInitStructure.CAN_FilterIdLow = 0 | CAN_ID_STD | CAN_RTR_DATA;
		}
		i++;
		if(i < len) {
			CAN_FilterInitStructure.CAN_FilterMaskIdHigh  = (ids[i] << 5) | CAN_ID_STD | CAN_RTR_DATA;
		} else {
			CAN_FilterInitStructure.CAN_FilterMaskIdHigh  = 0 | CAN_ID_STD | CAN_RTR_DATA;
		}
		i++;
		if(i < len) {
			CAN_FilterInitStructure.CAN_FilterMaskIdLow   = (ids[i] << 5) | CAN_ID_STD | CAN_RTR_DATA;
		} else {
			CAN_FilterInitStructure.CAN_FilterMaskIdLow   = 0 | CAN_ID_STD | CAN_RTR_DATA;
		}
		
		CAN_FilterInitStructure.CAN_FilterFIFOAssignment = can_fifo;
		CAN_FilterInitStructure.CAN_FilterActivation = ENABLE;
		CAN_FilterInit(&CAN_FilterInitStructure);
	}
	return fifoNum;
}

u8 CAN_SetFilterExtIds(u8 can_fifo, u8 fifoNum, u32 ids[], u8 len)
{
	CAN_FilterInitTypeDef  CAN_FilterInitStructure;
	u8 i = 0;
	while(fifoNum < CAN_MAX_FILTER && i < len) {
		CAN_FilterInitStructure.CAN_FilterNumber = fifoNum++;
		CAN_FilterInitStructure.CAN_FilterMode = CAN_FilterMode_IdList;
		CAN_FilterInitStructure.CAN_FilterScale = CAN_FilterScale_32bit;
		CAN_FilterInitStructure.CAN_FilterIdHigh = (((u32)ids[i] << 3) & 0xffff0000) >> 16;
		CAN_FilterInitStructure.CAN_FilterIdLow  = (((u32)ids[i] << 3) | CAN_ID_EXT | CAN_RTR_DATA) & 0xffff;
		i++;
		if(i < len) {
			CAN_FilterInitStructure.CAN_FilterMaskIdHigh  = (((u32)ids[i] << 3) & 0xffff0000) >> 16;
			CAN_FilterInitStructure.CAN_FilterMaskIdLow   = (((u32)ids[i] << 3) | CAN_ID_EXT | CAN_RTR_DATA) & 0xffff;
			i++;
		} else {
			CAN_FilterInitStructure.CAN_FilterMaskIdHigh  = 0;
			CAN_FilterInitStructure.CAN_FilterMaskIdLow   = (0 | CAN_ID_EXT | CAN_RTR_DATA) & 0xffff;
		}
		CAN_FilterInitStructure.CAN_FilterFIFOAssignment = can_fifo;
		CAN_FilterInitStructure.CAN_FilterActivation = ENABLE;
		CAN_FilterInit(&CAN_FilterInitStructure);
	}
	return fifoNum;
}

CAN_MsgRecvCallBackFunc CAN1_MsgRecvCallBackFunc;
CAN_MsgRecvCallBackFunc CAN2_MsgRecvCallBackFunc;

void CAN1_Config(CAN_SetupStructure *CAN_SetupStructure)
{
	GPIO_InitTypeDef        GPIO_InitStructure; 
	NVIC_InitTypeDef  		NVIC_InitStructure;
   	
	if(!CAN_SetupStructure->needRemap) {
		/*����ʱ������*/
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_AFIO, ENABLE);//ʹ��PORTAʱ��	                   											 
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_CAN1, ENABLE);//ʹ��CAN1ʱ��	
		
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_OD;	//��������
		GPIO_Init(GPIOA, &GPIO_InitStructure);			//��ʼ��IO

		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING ;	//��������
		GPIO_Init(GPIOA, &GPIO_InitStructure);			//��ʼ��IO 
	} else {
		/*����ʱ������*/
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO | RCC_APB2Periph_GPIOB, ENABLE);
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_CAN1, ENABLE);

		GPIO_PinRemapConfig(GPIO_Remap1_CAN1, ENABLE);
		
		/* Configure CAN pin: RX PB8*/									          
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;	             // ��������
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
		GPIO_Init(GPIOB, &GPIO_InitStructure);
		
		/* Configure CAN pin: TX PB9 */									               
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;		         // �����������
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; 
		GPIO_Init(GPIOB, &GPIO_InitStructure);
	}

#if CAN1_FIFO == CAN_FIFO0
	NVIC_InitStructure.NVIC_IRQChannel = CAN1_RX0_IRQn;
#elif CAN1_FIFO == CAN_FIFO1
	NVIC_InitStructure.NVIC_IRQChannel = CAN1_RX1_IRQn;
#endif
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;     // �����ȼ�Ϊ1
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;            // �����ȼ�Ϊ0
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

	CAN_bound(CAN1, CAN_SetupStructure->bps);
	
	u8 fifoNum = 0;
	if(CAN_SetupStructure->filterStdIdLen == 0 && CAN_SetupStructure->filterExtIdLen == 0) {
		CAN_SetAllfilter(CAN1_FIFO, fifoNum);
	} else {
		fifoNum = CAN_SetFilterStdIds(CAN1_FIFO, fifoNum, CAN_SetupStructure->filterStdIds, CAN_SetupStructure->filterStdIdLen);
		CAN_SetFilterExtIds(CAN1_FIFO, fifoNum, CAN_SetupStructure->filterExtIds, CAN_SetupStructure->filterExtIdLen);
	}
	
#if CAN1_FIFO == CAN_FIFO0
	CAN_ITConfig(CAN1, CAN_IT_FMP0, ENABLE);
#elif CAN1_FIFO == CAN_FIFO1
	CAN_ITConfig(CAN1, CAN_IT_FMP1, ENABLE);
#endif
	
	CAN1_MsgRecvCallBackFunc = CAN_SetupStructure->recv_func;
}


void CAN2_Config(CAN_SetupStructure *CAN_SetupStructure)
{
	GPIO_InitTypeDef        GPIO_InitStructure; 

	NVIC_InitTypeDef  		NVIC_InitStructure;
	
	if(!CAN_SetupStructure->needRemap) {
		/*����ʱ������*/
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB | RCC_APB2Periph_AFIO, ENABLE);//ʹ��PORTBʱ��	                   											 
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_CAN2, ENABLE);//ʹ��CAN2ʱ��	
		
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;	//��������
		GPIO_Init(GPIOB, &GPIO_InitStructure);			//��ʼ��IO

		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;	//��������
		GPIO_Init(GPIOB, &GPIO_InitStructure);			//��ʼ��IO
	} else {
	/*����ʱ������*/
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO | RCC_APB2Periph_GPIOB, ENABLE);
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_CAN2, ENABLE);

		GPIO_PinRemapConfig(GPIO_Remap_CAN2, ENABLE);
		
		/* Configure CAN pin: RX PB5*/									          
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;	             // ��������
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
		GPIO_Init(GPIOB, &GPIO_InitStructure);
		
		/* Configure CAN pin: TX PB6 */									               
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;		         // �����������
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; 
		GPIO_Init(GPIOB, &GPIO_InitStructure);
	}
	    
#if CAN2_FIFO == CAN_FIFO0
	NVIC_InitStructure.NVIC_IRQChannel = CAN2_RX0_IRQn;
#elif CAN2_FIFO == CAN_FIFO1
	NVIC_InitStructure.NVIC_IRQChannel = CAN2_RX1_IRQn;
#endif
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;     // �����ȼ�Ϊ1
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;            // �����ȼ�Ϊ0
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	
	CAN_bound(CAN2, CAN_SetupStructure->bps);
	
	u8 fifoNum = 14;
	if(CAN_SetupStructure->filterStdIdLen == 0 && CAN_SetupStructure->filterExtIdLen == 0) {
		CAN_SetAllfilter(CAN2_FIFO, fifoNum);
	} else {
		fifoNum = CAN_SetFilterStdIds(CAN2_FIFO, fifoNum, CAN_SetupStructure->filterStdIds, CAN_SetupStructure->filterStdIdLen);
		CAN_SetFilterExtIds(CAN2_FIFO, fifoNum, CAN_SetupStructure->filterExtIds, CAN_SetupStructure->filterExtIdLen);
	}
#if CAN2_FIFO == CAN_FIFO0
	CAN_ITConfig(CAN2, CAN_IT_FMP0, ENABLE);
#elif CAN2_FIFO == CAN_FIFO1
	CAN_ITConfig(CAN2, CAN_IT_FMP1, ENABLE);
#endif

	CAN2_MsgRecvCallBackFunc = CAN_SetupStructure->recv_func;
}

void CAN1_Disable()
{
#if CAN1_FIFO == CAN_FIFO0
	CAN_ITConfig(CAN1, CAN_IT_FMP0, DISABLE);
#elif CAN1_FIFO == CAN_FIFO1
	CAN_ITConfig(CAN1, CAN_IT_FMP1, DISABLE);
#endif
}

void CAN2_Disable()
{
#if CAN2_FIFO == CAN_FIFO0
	CAN_ITConfig(CAN2, CAN_IT_FMP0, DISABLE);
#elif CAN2_FIFO == CAN_FIFO1
	CAN_ITConfig(CAN2, CAN_IT_FMP1, DISABLE);
#endif
}


void CAN1_Enable()
{
#if CAN1_FIFO == CAN_FIFO0
	CAN_ITConfig(CAN1, CAN_IT_FMP0, ENABLE);
#elif CAN1_FIFO == CAN_FIFO1
	CAN_ITConfig(CAN1, CAN_IT_FMP1, ENABLE);
#endif
}

void CAN2_Enable()
{
#if CAN2_FIFO == CAN_FIFO0
	CAN_ITConfig(CAN2, CAN_IT_FMP0, ENABLE);
#elif CAN2_FIFO == CAN_FIFO1
	CAN_ITConfig(CAN2, CAN_IT_FMP1, ENABLE);
#endif
}



/*
 * ����can��չ֡����
 */
void CAN_SendExtMsg(TYPE_Can *canMsg)
{
	CanTxMsg canTxMsg;	
	
	canTxMsg.IDE = CAN_Id_Extended;
	canTxMsg.RTR = CAN_RTR_DATA;
	
	canTxMsg.ExtId = canMsg->id;

	canTxMsg.DLC = canMsg->dlc > 8 ? 8 : canMsg->dlc;
	
	memcpy(canTxMsg.Data, canMsg->data, canMsg->dlc);
	if(canMsg->ch == CAN_CH1) {
		CAN_Transmit(CAN1, &canTxMsg);
	} else if(canMsg->ch == CAN_CH2) {
		CAN_Transmit(CAN2, &canTxMsg);
	}		
}
/*
 * ����can��׼֡֡����
 */
void CAN_SendStdMsg(TYPE_Can *canMsg)
{
	CanTxMsg canTxMsg;	
	
	canTxMsg.IDE = CAN_Id_Standard;
	canTxMsg.RTR = CAN_RTR_DATA;
	
	canTxMsg.StdId = canMsg->id;

	canTxMsg.DLC = canMsg->dlc;
	
	memcpy(canTxMsg.Data, canMsg->data, canMsg->dlc);
	if(canMsg->ch == CAN_CH1) {
		CAN_Transmit(CAN1, &canTxMsg);
	} else if(canMsg->ch == CAN_CH2) {
		CAN_Transmit(CAN2, &canTxMsg);
	}		
}
#if CAN1_FIFO == CAN_FIFO0
//�жϷ�����		
void CAN1_RX0_IRQHandler(void)
{
	if(CAN1_MsgRecvCallBackFunc != NULL) {
		CanRxMsg RxMessage;
		CAN_Receive(CAN1, CAN1_FIFO, &RxMessage);
		CAN1_MsgRecvCallBackFunc(CAN_CH1, &RxMessage);
	}
}
#elif CAN1_FIFO == CAN_FIFO1
void CAN1_RX1_IRQHandler(void)
{
	if(CAN1_MsgRecvCallBackFunc != NULL) {
		CanRxMsg RxMessage;
		CAN_Receive(CAN1, CAN1_FIFO, &RxMessage);
		CAN1_MsgRecvCallBackFunc(CAN_CH1, &RxMessage);
	}
}
#endif

#if CAN2_FIFO == CAN_FIFO0
void CAN2_RX0_IRQHandler(void)
{
	if(CAN1_MsgRecvCallBackFunc != NULL) {
		CanRxMsg RxMessage;
		CAN_Receive(CAN2, CAN2_FIFO, &RxMessage);
		CAN1_MsgRecvCallBackFunc(CAN_CH2, &RxMessage);
	}
}
#elif CAN2_FIFO == CAN_FIFO1
void CAN2_RX1_IRQHandler(void)
{
	if(CAN1_MsgRecvCallBackFunc != NULL) {
		CanRxMsg RxMessage;
		CAN_Receive(CAN2, CAN2_FIFO, &RxMessage);
		CAN1_MsgRecvCallBackFunc(CAN_CH2, &RxMessage);
	}
}
#endif
