#ifndef __PWM_H__
#define __PWM_H__

#include "common.h"



void PWM_Init(void);


void PWM_SetDuty(u16 duty);







#endif

