#include "ccp.h"
#include "can.h" 


u8 ccp_is_disconnected(ccp_client_t *client) {
	return client->connectStatus == CONNECT_STATUS_DISCONNECT;
}

u8 ccp_is_connected(ccp_client_t *client) {
	return client->connectStatus == CONNECT_STATUS_CONNECTED;
}

void ccp_free(ccp_client_t *client)
{
	client->status = CCP_STATUS_FREE;
}

u8 ccp_is_free(ccp_client_t *client)
{
	return client->status == CCP_STATUS_FREE;
}

u8 ccp_send_msg(ccp_client_t *client, u8 data[], u16 timeout)
{
	TYPE_Can canMsg;
	canMsg.ch = client->config.canChange;
	canMsg.id = client->config.cmdCanId;
	canMsg.dlc = 8;
	memcpy(canMsg.data, data, 8);
	CAN_SendExtMsg(&canMsg);

	// ��ʱʱ��500ms
	client->timer = *client->ptimeTicks + timeout; 
	client->timeout = timeout;
	
	#if 0
	LOGDln("Send Can Msg:%02x,%02x,%02x,%02x,%02x,%02x,%02x,%02x\r\n",
		data[0], 
		data[1], 
		data[2], 
		data[3], 
		data[4], 
		data[5], 
		data[6], 
		data[7]
	);
	#endif

	
	return data[1];
}

//*************************************************************
// CCP����
//*************************************************************
u8 ccp_connect(ccp_client_t *client)
{
	if(!ccp_is_free(client) && client->connectStatus != CONNECT_STATUS_DISCONNECT) {
		return 0;
	}
	client->status = CCP_STATUS_CONECTING;
	
	memset(client->data, 0, 8);
	client->data[0] = CCP_CMD_CONNECT;
	client->data[1] = ++client->count;
	client->data[2] = (client->config.stationAddr >> 8) & 0xFF;
	client->data[3] = (client->config.stationAddr >> 0) & 0xFF;
	
	client->nextTaskFun = ccp_connect_callBack;
	
	ccp_send_msg(client, client->data, CCP_TIMEOUT);
	#if _DEBUG_CONNECT_
		LOGDln("ccp_command_connect:%d\r\n", client->data[1]);
	#endif 
	return 1;
}

void ccp_connect_callBack(ccp_client_t *client, u8 backMsg[])
{
	ccp_get_version(client);
}

/*
 * ccp_get_version
 */
u8 ccp_get_version(ccp_client_t *client)
{
	memset(client->data, 0, 8);
	client->data[0] = CCP_CMD_GET_VERSION;
	client->data[1] = ++client->count;
	client->data[2] = 0x02;
	client->data[3] = 0x01;
	
	client->nextTaskFun 	= ccp_get_version_callBack;
	
	ccp_send_msg(client, client->data, CCP_TIMEOUT);
	#if _DEBUG_CONNECT_
		LOGDln("ccp_command_get_version:%d\r\n", client->data[1]);
	#endif 
	return 1;
}
void ccp_get_version_callBack(ccp_client_t *client, u8 backMsg[])
{
	client->mainVersion 	= backMsg[2];
	client->releaseVersion = backMsg[3];
	ccp_get_exchange_id(client);
}


/*
 * ccp_get_exchange_id
 */
u8 ccp_get_exchange_id(ccp_client_t *client)
{
	memset(client->data, 0, 8);
	client->data[0] = CCP_CMD_EXCHANGE_ID;
	client->data[1] = ++client->count;

	client->nextTaskFun 	= ccp_get_exchange_id_callBack;
	
	ccp_send_msg(client, client->data, CCP_TIMEOUT);
	#if _DEBUG_CONNECT_
		LOGDln("ccp_command_get_exchange_id:%d\r\n", client->data[1]);
	#endif 
	return 1;
}

void ccp_get_exchange_id_callBack(ccp_client_t *client, u8 backMsg[]) 
{
	client->unlockCode = 0;
	ccp_get_seed(client);
}

/*
 * ccp_get_seed
 */
u8 ccp_get_seed(ccp_client_t *client)
{	
	memset(client->data, 0, 8);
	client->data[0] = CCP_CMD_GET_SEED;
	client->data[1] = ++client->count;
	u8 unlockCode = client->unlockCode;
	if(!GET_1BIT(unlockCode, 0)) {
		client->data[2] = 0x01;
	} else if(!GET_1BIT(unlockCode, 1)) {
		client->data[2] = 0x02;
	} else if(!GET_1BIT(unlockCode, 2)) {
		client->data[2] = 0x04;
	} else if(!GET_1BIT(unlockCode, 6)) {
		client->data[2] = 0x40;
	} else {
		client->status = CCP_STATUS_FREE;
		client->connectStatus = CONNECT_STATUS_CONNECTED;
		LOGDln("ccp connect success :0x%02x\r\n", unlockCode);
		return 2;
	}

	client->nextTaskFun = ccp_get_seed_callBack;
	
	ccp_send_msg(client, client->data, CCP_TIMEOUT);

	#if _DEBUG_CONNECT_
		LOGDln("ccp_command_get_seed:%d, %d, 0x%02x\r\n", client->data[1], 
			client->data[2], client->unlockCode);
	#endif 
	return 1;
}

void ccp_get_seed_callBack(ccp_client_t *client, u8 backMsg[])
{
	ccp_unlock(client);
}

/*
 * ccp_unlock
 */
u8 ccp_unlock(ccp_client_t *client)
{
	memset(client->data, 0, 8);
	client->data[0] = CCP_CMD_UNLOCK;
	client->data[1] = ++client->count;
	client->data[2] = (client->config.key >> 24) & 0xFF;
	client->data[3] = (client->config.key >> 16) & 0xFF;
	client->data[4] = (client->config.key >> 8)  & 0xFF;
	client->data[5] = (client->config.key >> 0)  & 0xFF;

	client->nextTaskFun 	= ccp_unlock_callBack;
	
	ccp_send_msg(client, client->data, CCP_TIMEOUT);
	#if _DEBUG_CONNECT_
		LOGDln("ccp_command_unlock:%d\r\n", client->data[1]);
	#endif 
	return 1;
}

void ccp_unlock_callBack(ccp_client_t *client, u8 backMsg[])
{
	client->unlockCode = backMsg[3];
	ccp_get_seed(client);
}

//*************************************************************
// ��������
//*************************************************************
void ccp_short_up(ccp_client_t *client)
{
	u16 leftSize = client->request.totalSize - client->request.sizeCount;
	u8 size = leftSize > 5 ? 5 : leftSize;
	u32 addr = client->config.startAddr 
					+ client->request.addrOffset 
					+ client->request.sizeCount;
	
	memset(client->data, 0, 8);
	client->data[0] = CCP_CMD_SHORT_UP;
	client->data[1] = ++client->count;
	client->data[2] = size;
	client->data[3] = 0;
	client->data[4] = (addr >> 24) & 0xFF;
	client->data[5] = (addr >> 16) & 0xFF;
	client->data[6] = (addr >> 8)  & 0xFF;
	client->data[7] = (addr >> 0)  & 0xFF;
	
	client->request.dealSize 	= client->data[2];
	client->nextTaskFun 	= ccp_short_up_callback;

	ccp_send_msg(client, client->data, CCP_TIMEOUT);	
	#if _DEBUG_CAL_
		LOGDln("ccp_short_up(cnt:%d, addr:%d)", ccp_task.data[1], addr);
	#endif
}

void ccp_short_up_callback(ccp_client_t *client, u8 backMsg[])
{
	if(client->data[0] != CCP_CMD_SHORT_UP) {
		return ;
	}
		
	memcpy(&client->buff[client->request.addrOffset + client->request.sizeCount], &backMsg[3], 
		client->request.dealSize);
	client->request.sizeCount += client->request.dealSize;
	
	if(client->request.sizeCount < client->request.totalSize) {
		// ���ݻ�δ������ɣ���������궨����
		ccp_short_up(client);
	} else {
		// �������
		LOGDln("ccp request datas success, len:%d", client->request.sizeCount);
		client->requestCallback(client, client->buff, client->request.totalSize);
		client->status = CCP_STATUS_FREE;
		#if _DEBUG_CAL_
			printArray(client->buff, ccp_task.sizeCount);
		#endif
	}
}
//*************************************************************
// ���ñ궨����
//*************************************************************
void ccp_set_mta(ccp_client_t *client) 
{
	u32 addr = client->config.startAddr 
				+ client->set.addrOffset 
				+ client->set.sizeCount;
	
	memset(client->data, 0, 8);
	client->data[0] = CCP_CMD_SET_MTA;
	client->data[1] = ++client->count;
	client->data[2] = 0;
	client->data[3] = 0;
	client->data[4] = (addr >> 24) & 0xFF;
	client->data[5] = (addr >> 16) & 0xFF;
	client->data[6] = (addr >> 8)  & 0xFF;
	client->data[7] = (addr >> 0)  & 0xFF;
	
	client->nextTaskFun = ccp_download;

	ccp_send_msg(client, client->data, CCP_TIMEOUT);
	#if _DEBUG_CAL_
		LOG("ccp_set_mta\r\n");
	#endif
}


void ccp_download(ccp_client_t *client, u8 backMsg[])
{
	if(client->data[0] != CCP_CMD_SET_MTA) {
		return ;
	}
	u16 leftSize = client->set.totalSize - client->set.sizeCount;
	u8 sendSize = leftSize > 5 ? 5 : leftSize;
	
	memset(client->data, 0, 8);
	client->data[0] = CCP_CMD_DOWNLOAD;
	client->data[1] = ++client->count;
	client->data[2] = sendSize;
	
	memcpy(&client->data[3], &client->buff[client->set.sizeCount], sendSize);
	
	client->set.dealSize = sendSize;
	client->nextTaskFun = ccp_download_callback;
	
	ccp_send_msg(client, client->data, CCP_TIMEOUT);
	#if _DEBUG_CAL_
		LOG("ccp_download, %d\r\n", sendSize);
	#endif
}


void ccp_download_callback(ccp_client_t *client, u8 backMsg[])
{
	if(client->data[0] != CCP_CMD_DOWNLOAD) {
		return;
	}
				
	client->set.sizeCount += client->set.dealSize;
	
	if(client->set.sizeCount < client->set.totalSize) {
		// ����δ��ɣ���������
		ccp_set_mta(client);
	} else {
		client->setCallback(client);
		client->status = CCP_STATUS_FREE;
		LOGDln("ccp set datas success, len:%d", client->set.sizeCount);
	}
	
}


/**
 *	ccp����Ͽ�����
 */
#define  CCP_DISCONNECT_TIME 	1000   // 1000msû��ccp������Ͽ�ccp����
extern void ccp_disconnect_callback(ccp_client_t *client, u8 backMsg[]);
void ccp_deal_disconnect(ccp_client_t *client)
{
	if(!client->isFree(client)) {
		client->disconnectTimer  = *client->ptimeTicks + CCP_DISCONNECT_TIME;
		return ;
	}
	
	if(client->isConnected(client) && client->disconnectTimer < *client->ptimeTicks) {
		
		memset(client->data, 0, 8);
		client->data[0] = CCP_CMD_DISCONNECT;
		client->data[1] = ++client->count;
		client->data[2] = 0x00; // 0x00 ��ʾ��ʱ�Ͽ���0x01 ��ʾ�����Ự
		client->data[3] = (client->config.stationAddr >> 8) & 0xFF;
		client->data[4] = (client->config.stationAddr >> 0) & 0xFF;
		
		client->nextTaskFun = (void (*)())ccp_disconnect_callback;
		client->status = CCP_STATUS_DISCONNECT;
		ccp_send_msg(client, client->data, 3000);
	}
}
void ccp_disconnect_callback(ccp_client_t *client, u8 backMsg[])
{
	if(backMsg[1] == 0x00) {
		client->free(client);
		client->connectStatus = CONNECT_STATUS_DISCONNECT;
		LOGDln("ccp disconnect success\r\n");
	} else {
		LOGDln("ccp disconnect failed\r\n");
	}
}

//*************************************************************
// ����궨����
//*************************************************************
void ccp_do_store(ccp_client_t *client)
{
	memset(client->data, 0, 8);
	client->data[0] = CCP_CMD_SET_S_STATUS;
	client->data[1] =  ++client->count;
	client->data[2] = (1 << 6);
	
	client->nextTaskFun = ccp_store_callback;
	
	ccp_send_msg(client, client->data, 3000);

}


void ccp_store_callback(ccp_client_t *client, u8 backMsg[])
{
	u8 isSuccess = backMsg[1] == 0x00;
	
	client->storeCallback(client, isSuccess);
	client->status = CCP_STATUS_FREE;
	client->connectStatus = CONNECT_STATUS_DISCONNECT;
}


/**
 *	ccp����CAN����
 */
u8 ccp_recv_can_msg(ccp_client_t *pClient, TYPE_Can *canMsg)
{
	if(pClient->config.ackCanId != canMsg->id
		|| pClient->config.canChange != canMsg->ch) {
		// canID ��ͨ�������䱸
		return 0;
	}
	
	if(canMsg->data[0] == 0xFF && canMsg->data[2] == pClient->data[1]) {
		if(canMsg->data[1] != 0x00) {
			pClient->errorCallback(pClient, pClient->status);
			pClient->free(pClient);
		}
		
		pClient->nextTaskFun(pClient, canMsg->data);
		pClient->timeoutCount = 0;
		pClient->timer = *pClient->ptimeTicks + CCP_TIMEOUT;
	}
	
	return 1;
}


/**
 *��ʱ����
 */
u8 ccp_deal_timeout(ccp_client_t *client)
{
	if(client->isFree(client)) {
		return 0;
	}
	
	if(client->timeoutCount >= CCP_TRY_TIMES) {
		
		LOGDln("ccp exec timeout:0x%02x,0x%02x,0x%02x,0x%02x,0x%02x,0x%02x,0x%02x,0x%02x\r\n", 
				client->data[0],
				client->data[1],
				client->data[2],
				client->data[3],
				client->data[4],
				client->data[5],
				client->data[6],
				client->data[7]
		);
		client->connectStatus = CONNECT_STATUS_DISCONNECT;
		client->timeoutCount = 0;
		client->taskFlag = 0;

		client->errorCallback(client, client->status);
		
		client->free(client);
		return 1;
	} else if(client->timer < *client->ptimeTicks) {
		client->timeoutCount++;
		LOGDln("ccp timeout %d times, resend:0x%02x\r\n", client->timeoutCount, client->data[0]);
//		LOGDln("0x%02x,0x%02x,0x%02x,0x%02x,0x%02x,0x%02x,0x%02x,0x%02x\r\n", 
//				client->data[0],
//				client->data[1],
//				client->data[2],
//				client->data[3],
//				client->data[4],
//				client->data[5],
//				client->data[6],
//				client->data[7]
//		);
		ccp_send_msg(client, client->data, client->timeout);
	}
	
	return 0;
}




