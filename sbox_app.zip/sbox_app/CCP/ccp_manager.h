#ifndef __CCP_MANAGER_H__
#define __CCP_MANAGER_H__


#include "ccp.h"
#include "common.h"


#define BLE_CCP_CMD_CONNECT 		(1 << 0)
#define BLE_CCP_CMD_DATA_REQUEST	(1 << 1)
#define BLE_CCP_CMD_DATA_SET		(1 << 2)
#define BLE_CCP_CMD_DATA_STORE		(1 << 3)


#pragma pack (1) // ָ����һ�ֽڶ���
typedef struct {
	u16 flag;
	u8 cmd;
	u8 ack;
	u16 offset;
	u16 totalSize;
	u16 currentOffset;
} ccp_control_t; 


#pragma pack () // ȡ��ָ���ṹ�����


void ccp_config(u8 *datas, u8 len);

void ccp_start(u8 *datas, u8 len);

void ccp_task_exec(void);

u8 ccp_deal_can_msg(TYPE_Can *canMsg);








#endif
