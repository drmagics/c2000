#include "ccp_manager.h"
#include "bt_manager.h"
#include "time_task.h"

extern u32 g_SysTicks;
extern u8 g_BtCanSendFlag;
void onRequestCalibrationDataCallback(ccp_client_t *client, u8 *datas, u16 len);
void onSetClibrationDataCallback(ccp_client_t *client);
void onStoreCalirtionDataCallback(ccp_client_t *client, u8 isSuccess);
void onErrorCallback(ccp_client_t *client, u8 status);

ccp_client_t g_ccpClient = {
	.status = CCP_STATUS_FREE,
	.connectStatus = CONNECT_STATUS_DISCONNECT,
	.isConnected = ccp_is_connected,
	.isDisConnected = ccp_is_disconnected,
	.free = ccp_free,
	.isFree = ccp_is_free,
	.ptimeTicks = &g_SysTicks,
	.requestCallback = onRequestCalibrationDataCallback,
	.setCallback = onSetClibrationDataCallback,
	.storeCallback = onStoreCalirtionDataCallback,
	.errorCallback = onErrorCallback
};


void onRequestCalibrationDataCallback(ccp_client_t *client, u8 *datas, u16 len)
{
	u16 sendMaxSize = 200;
	u16 sendSize;
	int leftSize = len;
	u16 offset = 0;
	ccp_control_t control;

	control.flag = g_ccpClient.config.flag;
	control.cmd = BLE_CCP_CMD_DATA_REQUEST;
	control.ack = CCP_ACK_SUCCESS;
	offset = client->request.addrOffset;
	do {
		sendSize = leftSize > sendMaxSize ? sendMaxSize : leftSize;
		control.offset = BigLittleSwap16(offset);
		control.totalSize = BigLittleSwap16(sendSize);
		
		BT_SendMsgWithHead(BT_ACK_CCP, &control, 8, &datas[offset], sendSize);
		LOGDln("BT send calibration datas, offset:%d, len:%d", offset, sendSize);
		leftSize -= sendSize;
		offset += sendSize;
	} while(leftSize != 0);
}

void onSetClibrationDataCallback(ccp_client_t *client)
{
	ccp_control_t control;
	
	control.flag = g_ccpClient.config.flag;
	control.cmd = BLE_CCP_CMD_DATA_SET;
	control.ack = CCP_ACK_SUCCESS;
	control.offset = BigLittleSwap16(client->set.addrOffset);
	control.totalSize =  BigLittleSwap16(client->set.totalSize);
	BT_SendMsg(BT_ACK_CCP, &control, 8);
}

void onStoreCalirtionDataCallback(ccp_client_t *client, u8 isSuccess)
{
	ccp_control_t control;
	
	control.flag = g_ccpClient.config.flag;
	control.cmd = BLE_CCP_CMD_DATA_STORE;
	control.ack = isSuccess ? CCP_ACK_SUCCESS : CCP_ACK_ERR;
	BT_SendMsg(BT_ACK_CCP, &control, 4);
}	


void onErrorCallback(ccp_client_t *client, u8 status)
{
	ccp_control_t control;
	
	control.flag = g_ccpClient.config.flag;
	control.ack = CCP_ACK_ERR;
	switch(status) {
		case CCP_STATUS_CONECTING:
			control.cmd = BLE_CCP_CMD_CONNECT;
			BT_SendMsg(BT_ACK_CCP, &control, 4);
			break;
		
		case CCP_STATUS_REQUSET_CAL:
			control.cmd = BLE_CCP_CMD_DATA_REQUEST;
			BT_SendMsg(BT_ACK_CCP, &control, 4);
			break;
		
		case CCP_STATUS_SET_CAL:
			control.cmd = BLE_CCP_CMD_DATA_SET;
			BT_SendMsg(BT_ACK_CCP, &control, 4);
			break;
		
		case CCP_STATUS_STORE:
			control.cmd = BLE_CCP_CMD_DATA_STORE;
			BT_SendMsg(BT_ACK_CCP, &control, 4);
			break;
		
		default:
			break;
	}
}

s32  ccp_TimeEnableCan(TimeTask_t *timeTask)
{
	CAN_Enable();
	timeTask->isUsed = FALSE;
	//g_BtCanSendFlag = 1;
	return 0;
}


/**
 * ����ccp��Ϣ
 */
void ccp_config(u8 *datas, u8 len)
{
	ccp_config_t *config = &g_ccpClient.config;
	if(len != sizeof(ccp_config_t)) {
		return ;
	}
	memcpy(config, datas, len);
	
	config->cmdCanId 		= BigLittleSwap32(config->cmdCanId);
	config->ackCanId 		= BigLittleSwap32(config->ackCanId);
	config->stationAddr 	= BigLittleSwap16(config->stationAddr);
	config->key 			= BigLittleSwap32(config->key);
	config->startAddr 		= BigLittleSwap32(config->startAddr);
	
	
	CAN_Disable();
	//g_BtCanSendFlag = 0;
	Task_Add(0, 10000, ccp_TimeEnableCan, NULL); // 10s�Ӻ���can�����ж�
	
	
	BT_SendMsg(BT_ACK_CCP_CONFIG, &config->flag, 2);
	
	
#if 1
	LOGDln("----------- ccp config -----------");
	LOGDln("carType:%d,devType:%d", config->flag & 0xFF, (config->flag >> 8) & 0xFF);
	LOGDln("canChange:%d", config->canChange);
	LOGDln("cmdCanId:0x%08X", config->cmdCanId);
	LOGDln("ackCanId:0x%08X", config->ackCanId);
	LOGDln("stationAddr:0x%04X", config->stationAddr);
	LOGDln("key:0x%08X", config->key);
	LOGDln("startAddr:0x%08X", config->startAddr);
	LOGDln("----------------------------------");
#endif
}

/**
 * ��ʼCCP����
 */
void ccp_start(u8 *datas, u8 len)
{
//	if(len < sizeof(ccp_control_t)) {
//		return ;
//	}
	u16 dataSize;
	ccp_client_t *pClient = &g_ccpClient;
	ccp_control_t *pControl = (ccp_control_t *)datas;
	
	if(pClient->config.flag != pControl->flag) {
		LOGDln("ccp config flag error :%d, %d", pClient->config.flag, pControl->flag);
		return ;
	}

	pClient->count = 0;
	pClient->timer = 0;
	pClient->timeoutCount = 0;
	
	if(pControl->cmd == BLE_CCP_CMD_DATA_REQUEST) {
		pClient->request.addrOffset = BigLittleSwap16(pControl->offset);
		pClient->request.totalSize = BigLittleSwap16(pControl->totalSize);
		LOGDln("request cal:%d, %d\r\n", pClient->request.addrOffset, pClient->request.totalSize);
		pClient->taskFlag |= pControl->cmd;
		
		pControl->ack = CCP_ACK_OK;
		BT_SendMsg(BT_ACK_CCP, pControl, 4);
		CAN_Enable();
		//g_BtCanSendFlag = 1;
	} else if(pControl->cmd == BLE_CCP_CMD_DATA_SET) {
//		printArray(datas, len);
		pClient->set.addrOffset = BigLittleSwap16(pControl->offset);
		pClient->set.totalSize = BigLittleSwap16(pControl->totalSize);
		pControl->currentOffset = BigLittleSwap16(pControl->currentOffset);
	
		LOGDln("set cal:%d, %d", pClient->set.totalSize, pControl->currentOffset);
		
		dataSize = len - sizeof(ccp_control_t);
		memcpy(&pClient->buff[pControl->currentOffset], &datas[sizeof(ccp_control_t)], dataSize);
		
		pControl->ack = CCP_ACK_OK;
		BT_SendMsg(BT_ACK_CCP, pControl, 4);
		
		if(pClient->set.totalSize == pControl->currentOffset + dataSize) {
			pClient->taskFlag |= pControl->cmd;
			CAN_Enable();
			//g_BtCanSendFlag = 1;
		}
	} else if(pControl->cmd == BLE_CCP_CMD_DATA_STORE) {
		pClient->taskFlag |= pControl->cmd;
		pControl->ack = CCP_ACK_OK;
		BT_SendMsg(BT_ACK_CCP, pControl, 4);
		CAN_Enable();
		//g_BtCanSendFlag = 1;
	}
}

/**
 * ����궨����
 */
u8 cpp_request_datas(ccp_client_t *client)
{
	if(!client->isFree(client)) {
		return 0;
	}
	
	if(!client->isConnected(client)) {
		client->taskFlag |= BLE_CCP_CMD_CONNECT;
		return 0;
	}
	client->status = CCP_STATUS_REQUSET_CAL;
	client->request.sizeCount = 0;

	LOGDln("start request calibration data:%d,%d\r\n",client->request.addrOffset, client->request.totalSize);
	ccp_short_up(client);
	
	return 1;
}
/**
 * ���ñ궨����
 */
u8 ccp_set_datas(ccp_client_t *client)
{
	if(!client->isFree(client)) {
		return 0;
	}
	if(!client->isConnected(client)) {
		client->taskFlag |= BLE_CCP_CMD_CONNECT;
		return 0;
	}
	client->status = CCP_STATUS_SET_CAL;
	client->set.sizeCount = 0;
	
	LOGDln("start set calibration data:%d,%d\r\n",client->set.addrOffset, client->set.totalSize);
	ccp_set_mta(client);
	return 1;
}

/**
 * ����궨���ݣ�ʹ�豸�е�CCP������Ч
 */
u8 ccp_store_datas(ccp_client_t *pClient)
{
	if(!pClient->isFree(pClient)) {
		return 0;
	}
	if(!pClient->isConnected(pClient)) {
		pClient->taskFlag |= BLE_CCP_CMD_CONNECT;
		return 0;
	}
	pClient->status = CCP_STATUS_STORE;
	
	LOGDln("start store calibration datas\r\n");
	ccp_do_store(pClient);
		
	return 1;
}
/**
 * ִ��CCP���񣬷�����ѭ����
 */
void ccp_task_exec()
{
	ccp_client_t *pClient = &g_ccpClient;
	if(pClient->taskFlag & BLE_CCP_CMD_CONNECT
		&& ccp_connect(pClient)) {
		// ccp����
		pClient->taskFlag &= ~BLE_CCP_CMD_CONNECT;
	}
	
	if(pClient->taskFlag & BLE_CCP_CMD_DATA_REQUEST 
		&& cpp_request_datas(pClient)) {			
		// ����궨����	
		pClient->taskFlag &= ~BLE_CCP_CMD_DATA_REQUEST;
	}
	
	if(pClient->taskFlag & BLE_CCP_CMD_DATA_SET
		&& ccp_set_datas(pClient)) {			
		// ���ñ궨����	
		pClient->taskFlag &= ~BLE_CCP_CMD_DATA_SET;
	}
		
	if(pClient->taskFlag & BLE_CCP_CMD_DATA_STORE
		&& ccp_store_datas(pClient)) {		
		// ����궨����	
		pClient->taskFlag &= ~BLE_CCP_CMD_DATA_STORE;
	}
		
	ccp_deal_timeout(pClient);
	ccp_deal_disconnect(pClient);
}

u8 ccp_deal_can_msg(TYPE_Can *canMsg)
{
	return ccp_recv_can_msg(&g_ccpClient, canMsg);
}

