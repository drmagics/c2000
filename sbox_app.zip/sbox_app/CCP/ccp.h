#ifndef __CCP_H__
#define __CCP_H__

#include <stdio.h>
#include <string.h>
#include "can_manager.h"


#include "common.h"

#define CCP_CMD_NULL				0xFF

#define CCP_CMD_INIT				0x00
#define CCP_CMD_CONNECT 			0x01
#define CCP_CMD_GET_VERSION 		0x1B
#define CCP_CMD_EXCHANGE_ID			0x17
#define CCP_CMD_GET_SEED			0x12
#define CCP_CMD_UNLOCK 				0x13
#define CCP_CMD_SELECT_CAL_PAGE		0x11
#define CCP_CMD_UPLOAD				0x04
#define CCP_CMD_SHORT_UP			0x0F
#define CCP_CMD_SET_MTA 			0x02
#define CCP_CMD_DOWNLOAD			0x03
#define CCP_CMD_SET_S_STATUS		0x0C
#define CCP_CMD_DISCONNECT			0x07

#define CCP_CMD_INIT_DAQ			0x00
#define CCP_CMD_GET_DAQ_SIZE		0x14
#define CCP_CMD_SET_DAQ_PTR			0x15
#define CCP_CMD_WRITE_DAQ			0x16
#define CCP_CMD_START_STOP_DAQ		0x06

#define CCP_TIMEOUT 			20				// 10ms
#define CCP_TRY_TIMES			5


#define CCP_ACK_SUCCESS			0x02
#define CCP_ACK_OK				0x01
#define CCP_ACK_ERR				0x00

// ccp״̬
#define CCP_STATUS_FREE 			0
#define CCP_STATUS_CONECTING	 	1
#define CCP_STATUS_REQUSET_CAL		5
#define CCP_STATUS_SET_CAL			6
#define CCP_STATUS_STORE			7
#define CCP_STATUS_CONNECT_CHECK	8
#define CCP_STATUS_DISCONNECT		9

// ccp����״̬
#define CONNECT_STATUS_DISCONNECT	0
#define CONNECT_STATUS_CONNECTED	1


#define CCP_BUFF_LEN			1024

typedef struct ccp_client ccp_client_t;

#pragma pack (1) // ָ����һ�ֽڶ���

typedef struct {
	u16 flag;			// ���ñ�ʶ
	u32 cmdCanId;		// ccp����CAN ID
	u32 ackCanId;		// ccp�ظ�CAN ID
	u16 stationAddr;	// 
	u32 key;			// ��Կ
	u8 canChange;		// canͨ��
	u32 startAddr;		// ��ʼ��ַ
} ccp_config_t;

#pragma pack () // ȡ��ָ���ṹ�����

// �������ݽṹ��
typedef struct {
	u16 addrOffset;
	u16 totalSize;
	u8 dealSize;
	u16 sizeCount;
	u16 lastOffset;
} ccp_request_t, ccp_set_t;


struct ccp_client {
	ccp_config_t config;
	
	ccp_request_t request;
	
	ccp_set_t	set;
	
	u8 status;
	u8 connectStatus;
	u8 taskFlag;
	
	u8 mainVersion;			// ccp���汾
	u8 releaseVersion;		// ccp�����汾
	u8 deviceIdLen;			// �豸ID����
	u8 unlockCode;			// ������
	
	u8 count;
	
	u8 data[8];
	u32 *ptimeTicks;
	u32 timer;
	u32 timeout;
	u32 disconnectTimer;
	u8 timeoutCount;
	void (*nextTaskFun)(ccp_client_t *, u8[]);
	
	u8 (*isConnected)(ccp_client_t *);
	u8 (*isDisConnected)(ccp_client_t *);
	
	void (*free)(ccp_client_t *);
	u8 (*isFree)(ccp_client_t *);
	
	u8 buff[CCP_BUFF_LEN];
	void (*requestCallback)(ccp_client_t *, u8 *, u16);
	void (*setCallback)(ccp_client_t *);
	void (*storeCallback)(ccp_client_t *, u8);
	void (*errorCallback)(ccp_client_t *, u8);
};

extern u8 ccp_is_disconnected(ccp_client_t *client);
extern u8 ccp_is_connected(ccp_client_t *client);
extern void ccp_free(ccp_client_t *client);
extern u8 ccp_is_free(ccp_client_t *client);

extern u8 ccp_send_msg(ccp_client_t *client, u8 data[], u16 timeout);
extern u8 ccp_get_version(ccp_client_t *client);
extern u8 ccp_get_exchange_id(ccp_client_t *client);
extern u8 ccp_get_seed(ccp_client_t *client);
extern u8 ccp_unlock(ccp_client_t *client);

extern void ccp_connect_callBack(ccp_client_t *client, u8 backMsg[]);
extern void ccp_get_version_callBack(ccp_client_t *client, u8 backMsg[]);
extern void ccp_get_exchange_id_callBack(ccp_client_t *client, u8 backMsg[]);
extern void ccp_get_seed_callBack(ccp_client_t *client,u8 backMsg[]);
extern void ccp_unlock_callBack(ccp_client_t *client, u8 backMsg[]);

extern void ccp_short_up(ccp_client_t *client);
extern void ccp_short_up_callback(ccp_client_t *client, u8 backMsg[]);

extern void ccp_set_mta(ccp_client_t *client);
extern void ccp_download(ccp_client_t *client, u8 backMsg[]);
extern void ccp_download_callback(ccp_client_t *client, u8 backMsg[]);

extern void ccp_do_store(ccp_client_t *client);
extern void ccp_store_callback(ccp_client_t *client, u8 backMsg[]);

extern void ccp_deal_disconnect(ccp_client_t *client);
extern u8 ccp_connect(ccp_client_t *client);
extern u8 ccp_deal_timeout(ccp_client_t *client);
extern void ccp_deal_disconnect(ccp_client_t *client);
extern u8 ccp_recv_can_msg(ccp_client_t *pClient, TYPE_Can *canMsg);
#endif
