#include <stdio.h>
#include "delay.h"
#include "common.h"
#include "string.h"
#include "uart.h"
#include "gpio.h"
#include "timer.h"
#include "msg.h"
#include "rtc.h"
#include "update.h"
#include "wdg.h"
#include "time_task.h"
#include "power.h"
#include "can_manager.h"
#include "uart_manager.h"
#include "led.h"
#include "bt_config.h"
#include "ISOTP.h"

extern u8 g_BtCanPkgCount;
void uart_test() {
	static u8 count;
	LOGDln("countt:%d,%d,%d", count++, g_BtCanPkgCount,sizeof(u32));
	
	
//  TYPE_Can canMsg;
//	canMsg.data[0] =6 ;
//	canMsg.ch = CAN_CH2;
//	canMsg.id = 0x18181818;
//	canMsg.dlc = 8;
//	CAN_SendExtMsg(&canMsg);


}
void UDS_Fuction(){
      FILE_Hand_Flush(); 		
	  UDS_SREVE();
}


extern void ccp_task_exec(void);

int main(void)
{			
	SCB->VTOR = UPDATE_FLASH_APP_ADDR;
	__enable_irq();
	
	UPDATE_WriteAppRunFlag();
	
 	delay_init();	    	 // ��ʱ������ʼ��
    ISOTP_Init();				 // UDS�ײ��ʼ��
	GPIO_InitDefault();
	
	UART_DEBUG_Init(115200);
	BT_Config_Init();
	UART_BT_Init(115200 * 4);
	
	CAN_InitDefault();
	LED_Init();
	
	LOGDln("sBox APP startABC:"VERSION_NAME);
	
	delay_ms(10);

	Task_Add(300, 1000, (TimeTaskFunc_t)uart_test, NULL);
	Task_Add(0, 50, (TimeTaskFunc_t)ccp_task_exec, NULL);
    Task_Add(0, 5, (TimeTaskFunc_t)UDS_Fuction, NULL);
	while(1)
	{			
	    MSG_DealCanMsg();
		MSG_DealUartMsg();
		Task_Exec();
	}
}


/*********************************************END OF FILE**********************/

